﻿using System;
using UnityEngine;

/// <summary>
/// 模型查看相机控制器
/// 支持鼠标操作和GUI参数调整
/// </summary>
public class ModelViewCamera : MonoBehaviour
{
    [Header("启用控制")]
    [Tooltip("启用/禁用相机控制的快捷键")]
    public KeyCode enableControlKey = KeyCode.F2;
    [Tooltip("默认是否启用相机控制")]
    public bool enabledByDefault = false;

    [Header("目标设置")]
    [Tooltip("观察的目标点，如果为空则使用世界原点")]
    public Transform target;

    [Header("旋转控制")]
    [Tooltip("鼠标灵敏度")]
    public float mouseSensitivity = 2f;
    [Tooltip("垂直旋转限制（度）")]
    public float verticalLimit = 80f;
    [Tooltip("是否反转鼠标Y轴")]
    public bool invertY = false;

    [Header("缩放控制")]
    [Tooltip("缩放速度")]
    public float zoomSpeed = 2f;
    [Tooltip("最小距离")]
    public float minDistance = 1f;
    [Tooltip("最大距离")]
    public float maxDistance = 20f;
    [Tooltip("初始距离")]
    public float initialDistance = 5f;

    [Header("平移控制")]
    [Tooltip("平移速度")]
    public float panSpeed = 1f;
    [Tooltip("平移按键")]
    public KeyCode panKey = KeyCode.LeftShift;

    [Header("自动旋转")]
    [Tooltip("是否启用自动旋转")]
    public bool autoRotate = false;
    [Tooltip("自动旋转速度")]
    public float autoRotateSpeed = 10f;

    [Header("重置设置")]
    [Tooltip("重置按键")]
    public KeyCode resetKey = KeyCode.R;
    [Tooltip("重置时的初始角度")]
    public Vector2 initialAngles = new Vector2(0f, 0f); // x: 水平角度, y: 垂直角度

    [Header("GUI设置")]
    [Tooltip("是否显示控制面板")]
    public bool showControlPanel = true;
    [Tooltip("面板透明度")]
    [Range(0.3f, 1f)]
    public float panelAlpha = 0.8f;



    // 私有变量
    private Vector3 targetPosition;
    private float currentDistance;
    private float horizontalAngle;
    private float verticalAngle;
    private Vector3 lastMousePosition;
    private bool isDragging = false;
    private bool isPanning = false;

    // 控制启用状态
    private bool cameraControlEnabled = false;

    // GUI相关
    private GUIStyle panelStyle;
    private GUIStyle labelStyle;
    private GUIStyle buttonStyle;
    private GUIStyle sliderStyle;
    private GUIStyle statusStyle;
    private bool stylesInitialized = false;
    private Rect panelRect;
    private bool showPanel = true;

    // 原始相机参数保存
    private Vector3 originalPosition;
    private Quaternion originalRotation;




    void Start()
    {


        // 初始化目标位置
        if (target != null)
        {
            targetPosition = target.position;
        }
        else
        {
            targetPosition = Vector3.zero;
        }

        // 初始化相机参数
        currentDistance = initialDistance;
        horizontalAngle = initialAngles.x;
        verticalAngle = initialAngles.y;
        // 保存原始相机参数
        originalPosition = transform.position;
        originalRotation = transform.rotation;
        // 设置初始启用状态
        cameraControlEnabled = enabledByDefault;

        // 设置初始相机位置
        //UpdateCameraPosition();

        // 初始化GUI面板位置
        panelRect = new Rect((Screen.width - 240) / 2, (Screen.height - 500) / 2, 240, 500);
        //X坐标：(屏幕宽度 - 面板宽度) / 2
        //Y坐标：(屏幕高度 - 面板高度) / 2

        // 输出提示信息
        Debug.Log($"相机控制器已加载。按 {enableControlKey} 键启用/禁用相机控制。");
    }

    void Update()
    {
        // 检测启用/禁用快捷键
        if (Input.GetKeyDown(enableControlKey))
        {
            cameraControlEnabled = !cameraControlEnabled;
            Debug.Log($"相机控制 {(cameraControlEnabled ? "已启用" : "已禁用")}");
            ResetCamera();

            // 禁用时重置拖拽状态
            if (!cameraControlEnabled)
            {
                isDragging = false;
                isPanning = false;
            }
        }

        // 只有在启用状态下才处理输入
        if (cameraControlEnabled)
        {
            HandleInput();

            if (autoRotate && !isDragging && !isPanning)
            {
                horizontalAngle += autoRotateSpeed * Time.deltaTime;
            }
        }

        UpdateCameraPosition();
    }

    void HandleInput()
    {
        // 重置按键
        if (Input.GetKeyDown(resetKey))
        {
            ResetCamera();
        }

        // 鼠标滚轮缩放
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll != 0)
        {
            currentDistance -= scroll * zoomSpeed;
            currentDistance = Mathf.Clamp(currentDistance, minDistance, maxDistance);
        }

        // 鼠标拖拽旋转
        if (Input.GetMouseButtonDown(0))
        {
            isDragging = true;
            lastMousePosition = Input.mousePosition;
        }
        else if (Input.GetMouseButtonUp(0))
        {
            isDragging = false;
        }

        if (isDragging)
        {
            Vector3 deltaMousePosition = Input.mousePosition - lastMousePosition;

            horizontalAngle += deltaMousePosition.x * mouseSensitivity * 0.1f;

            float verticalDelta = deltaMousePosition.y * mouseSensitivity * 0.1f;
            if (invertY) verticalDelta = -verticalDelta;

            verticalAngle -= verticalDelta;
            verticalAngle = Mathf.Clamp(verticalAngle, -verticalLimit, verticalLimit);

            lastMousePosition = Input.mousePosition;
        }

        // 平移控制
        if (Input.GetKeyDown(panKey) && Input.GetMouseButtonDown(1))
        {
            isPanning = true;
            lastMousePosition = Input.mousePosition;
        }
        else if (Input.GetMouseButtonUp(1) || Input.GetKeyUp(panKey))
        {
            isPanning = false;
        }

        if (isPanning)
        {
            Vector3 deltaMousePosition = Input.mousePosition - lastMousePosition;

            Vector3 right = transform.right;
            Vector3 up = transform.up;

            Vector3 panOffset = (-right * deltaMousePosition.x + up * deltaMousePosition.y) * panSpeed * 0.01f;
            targetPosition += panOffset;

            lastMousePosition = Input.mousePosition;
        }
    }

    void UpdateCameraPosition()
    {
        // 只有在启用状态下才更新相机位置
        if (!cameraControlEnabled)
        {
            // 保持原始位置和旋转
            transform.position = originalPosition;
            transform.rotation = originalRotation;
            return;
        }

        // 计算相机位置
        Quaternion rotation = Quaternion.Euler(verticalAngle, horizontalAngle, 0);
        Vector3 direction = rotation * Vector3.back;

        transform.position = targetPosition + direction * currentDistance;
        transform.LookAt(targetPosition);
    }

    void ResetCamera()
    {
        if (target != null)
        {
            targetPosition = target.position;
        }
        else
        {
            targetPosition = Vector3.zero;
        }

        currentDistance = initialDistance;
        horizontalAngle = initialAngles.x;
        verticalAngle = initialAngles.y;

        UpdateCameraPosition();
    }

    void InitializeGUIStyles()
    {
        if (stylesInitialized) return;

        panelStyle = new GUIStyle(GUI.skin.box)
        {
            padding = new RectOffset(10, 10, 10, 10)
        };

        labelStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 11,
            wordWrap = true
        };

        buttonStyle = new GUIStyle(GUI.skin.button)
        {
            fontSize = 10,
            padding = new RectOffset(6, 6, 3, 3)
        };

        sliderStyle = new GUIStyle(GUI.skin.horizontalSlider);

        statusStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 12,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleCenter
        };

        stylesInitialized = true;
    }

    void OnGUI()
    {
        InitializeGUIStyles();

        // 设置GUI颜色和透明度
        Color originalColor = GUI.color;
        GUI.color = new Color(1f, 1f, 1f, panelAlpha);

        // 在屏幕左上角显示状态和快捷键提示
        DrawStatusInfo();

        // 只有在启用控制且显示面板时才显示控制面板
        if (showControlPanel && cameraControlEnabled)
        {
            panelRect = GUI.Window(12345, panelRect, DrawControlPanel, "相机控制", panelStyle);
        }

        GUI.color = originalColor;
    }

    void DrawStatusInfo()
    {
        // 状态显示区域
        float statusWidth = 150f;
        float statusHeight = 60f;
        Rect statusRect = new Rect(Screen.width - statusWidth - 10, Screen.height - statusHeight - 10, statusWidth, statusHeight);

        GUI.Box(statusRect, "");

        GUILayout.BeginArea(statusRect);
        GUILayout.BeginVertical();

        // 状态显示
        GUI.color = cameraControlEnabled ? Color.green : Color.red;
        GUILayout.Label($"相机控制: {(cameraControlEnabled ? "启用" : "禁用")}", statusStyle);
        GUI.color = Color.white;

        // 快捷键提示
        GUILayout.Label($"        按 {enableControlKey} 切换控制状态", labelStyle);

        GUILayout.EndVertical();
        GUILayout.EndArea();
    }

    void DrawControlPanel(int windowID)
    {
        GUILayout.BeginVertical();

        // 显示/隐藏面板按钮
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        if (GUILayout.Button(showPanel ? "▼" : "▲", buttonStyle, GUILayout.Width(20)))
        {
            showPanel = !showPanel;
            panelRect.height = showPanel ? 500 : 40;
        }
        GUILayout.EndHorizontal();

        if (!showPanel)
        {
            GUI.DragWindow();
            GUILayout.EndVertical();
            return;
        }

        GUILayout.Space(5);

        // 启用状态控制
        GUILayout.BeginHorizontal();
        bool newEnabled = GUILayout.Toggle(cameraControlEnabled, "启用相机控制", GUILayout.Width(120));
        if (newEnabled != cameraControlEnabled)
        {
            cameraControlEnabled = newEnabled;
            if (!cameraControlEnabled)
            {
                isDragging = false;
                isPanning = false;
            }
        }
        GUILayout.EndHorizontal();

        GUILayout.Space(5);

        // 只有在启用状态下才显示其他控制
        GUI.enabled = cameraControlEnabled;

        // 距离控制
        GUILayout.Label($"距离: {currentDistance:F1}", labelStyle);
        float newDistance = GUILayout.HorizontalSlider(currentDistance, minDistance, maxDistance, sliderStyle, GUI.skin.horizontalSliderThumb);
        if (Math.Abs(newDistance - currentDistance) > 0.01f)
        {
            currentDistance = newDistance;
        }

        GUILayout.Space(5);

        // 角度显示和控制
        GUILayout.Label($"水平角度: {horizontalAngle:F0}°", labelStyle);
        float newHorizontalAngle = GUILayout.HorizontalSlider(horizontalAngle, -180f, 180f, sliderStyle, GUI.skin.horizontalSliderThumb);
        if (Math.Abs(newHorizontalAngle - horizontalAngle) > 0.1f)
        {
            horizontalAngle = newHorizontalAngle;
        }

        GUILayout.Label($"垂直角度: {verticalAngle:F0}°", labelStyle);
        float newVerticalAngle = GUILayout.HorizontalSlider(verticalAngle, -verticalLimit, verticalLimit, sliderStyle, GUI.skin.horizontalSliderThumb);
        if (Math.Abs(newVerticalAngle - verticalAngle) > 0.1f)
        {
            verticalAngle = newVerticalAngle;
        }

        GUILayout.Space(5);

        // 控制参数
        GUILayout.Label($"鼠标灵敏度: {mouseSensitivity:F1}", labelStyle);
        mouseSensitivity = GUILayout.HorizontalSlider(mouseSensitivity, 0.5f, 5f, sliderStyle, GUI.skin.horizontalSliderThumb);

        GUILayout.Label($"缩放速度: {zoomSpeed:F1}", labelStyle);
        zoomSpeed = GUILayout.HorizontalSlider(zoomSpeed, 0.5f, 5f, sliderStyle, GUI.skin.horizontalSliderThumb);

        GUILayout.Space(5);

        // 自动旋转控制
        //bool newAutoRotate = GUILayout.Toggle(autoRotate, "自动旋转", GUILayout.Width(80));
        //if (newAutoRotate != autoRotate)
        //{
        //    autoRotate = newAutoRotate;
        //}

        //if (autoRotate)
        //{
        //    GUILayout.Label($"旋转速度: {autoRotateSpeed:F0}°/s", labelStyle);
        //    autoRotateSpeed = GUILayout.HorizontalSlider(autoRotateSpeed, -50f, 50f, sliderStyle, GUI.skin.horizontalSliderThumb);
        //}

        //GUILayout.Space(10);

        // 控制按钮
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("重置视角", buttonStyle))
        {
            ResetCamera();
        }
        if (GUILayout.Button("俯视", buttonStyle))
        {
            SetPresetView(0, 90);
        }
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("正视", buttonStyle))
        {
            SetPresetView(0, 0);
        }
        if (GUILayout.Button("侧视", buttonStyle))
        {
            SetPresetView(90, 0);
        }
        GUILayout.EndHorizontal();

        GUI.enabled = true; // 重置GUI启用状态

        GUILayout.Space(10);

        // 操作说明
        GUILayout.Label("操作说明:", labelStyle);
        GUILayout.Label($"• {enableControlKey}键: 启用/禁用控制", labelStyle);
        GUILayout.Label("• 左键拖拽: 旋转视角", labelStyle);
        GUILayout.Label("• 滚轮: 缩放距离", labelStyle);
        GUILayout.Label($"• {panKey}+右键: 平移视角", labelStyle);
        GUILayout.Label($"• {resetKey}键: 重置视角", labelStyle);

        GUILayout.EndVertical();

        // 允许拖拽窗口
        GUI.DragWindow();
    }

    void SetPresetView(float horizontal, float vertical)
    {
        horizontalAngle = horizontal;
        verticalAngle = vertical;
    }

    // 公共方法供外部调用
    public void SetTarget(Transform newTarget)
    {
        target = newTarget;
        if (target != null)
        {
            targetPosition = target.position;
        }
    }

    public void SetTarget(Vector3 position)
    {
        target = null;
        targetPosition = position;
    }

    public void FocusOnBounds(Bounds bounds)
    {
        targetPosition = bounds.center;

        // 根据包围盒大小自动调整距离
        float maxSize = Mathf.Max(bounds.size.x, bounds.size.y, bounds.size.z);
        currentDistance = maxSize * 2f;
        currentDistance = Mathf.Clamp(currentDistance, minDistance, maxDistance);
    }

    // 启用/禁用控制面板
    public void SetControlPanelVisible(bool visible)
    {
        showControlPanel = visible;
    }

    // 启用/禁用相机控制
    public void SetCameraControlEnabled(bool enabled)
    {
        cameraControlEnabled = enabled;
        if (!enabled)
        {
            isDragging = false;
            isPanning = false;
        }
    }

    // 获取当前控制状态
    public bool IsCameraControlEnabled()
    {
        return cameraControlEnabled;
    }
}
