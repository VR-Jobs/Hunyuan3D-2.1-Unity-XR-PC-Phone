﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;
using Newtonsoft.Json;
using GLTFast;
using SimpleFileBrowser;
using Unity.VisualScripting;


#if UNITY_EDITOR
using UnityEditor;
#endif

/// <summary>
/// Hunyuan3D Unity客户端
/// 用于与Flask API服务器交互，上传图片并生成3D模型
/// </summary>
public class UnityHunyuanClient : MonoBehaviour
{
    [Header("服务器配置")]
    public string serverUrl = "http://175.155.64.171:31341";

    [Header("文件路径设置")]
    [Tooltip("是否使用相对路径（推荐用于打包）")]
    public bool useRelativePath = true;

    [Tooltip("相对路径下载文件夹名称")]
    public string relativeDownloadFolder = "HunyuanModels";

    [Tooltip("绝对路径（仅编辑器使用）")]
    public string absoluteDownloadFolder = @"D:\0.Unity20242024\unity-MCPnew\Assets\0.HunyuanModel";

    [Header("生成参数")]
    [Range(10, 100)]
    public int steps = 30;
    [Range(1.0f, 20.0f)]
    public float guidanceScale = 7.5f;
    [Range(0, 9999999)]
    public int seed = 1234;
    [Range(64, 512)]
    public int octreeResolution = 256;
    public bool removeBackground = true;
    public bool randomizeSeed = false;
    public bool includeTexture = true;
    public string fileType = "glb";
    [Range(50000, 500000)]
    public int numChunks = 200000;

    [Header("UI设置")]
    public bool showAdvancedOptions = false;

    [Header("模型显示设置")]
    public Transform modelParent; // 模型父对象
    public float rotationSpeed = 30f; // 旋转速度
    public Vector3 modelScale = Vector3.one; // 模型缩放

    // 私有变量
    private bool isConnected = false;
    private bool isGenerating = false;
    private string connectionStatus = "未连接";
    private string selectedImagePath = "";
    private string lastError = "";
    private float progress = 0f;
    private string progressMessage = "";
    private ServerInfo serverInfo;
    private GenerationResult lastResult;
    private GameObject currentModel; // 当前加载的模型

    // 图片预览相关
    private Texture2D currentImageTexture;
    private int imagePreviewSize = 150;

    // GUI样式
    private GUIStyle titleStyle;
    private GUIStyle buttonStyle;
    private GUIStyle boxStyle;
    private GUIStyle labelStyle;
    private bool stylesInitialized = false;

    // 滚动位置
    private Vector2 scrollPosition = Vector2.zero;

    // 在类的私有变量部分添加一个计数器
    private int modelCounter = 0;

    // 当前使用的下载文件夹路径
    private string currentDownloadFolder;

    // 在私有变量部分添加这些
    private List<ModelInfo> allModels = new List<ModelInfo>(); // 存储所有模型信息
    private List<bool> modelToggleStates = new List<bool>(); // 存储每个模型的toggle状态

    // 添加模型信息类
    [System.Serializable]
    public class ModelInfo
    {
        public GameObject modelObject;
        public string modelName;
        public string filePath;
    }

    // 在私有变量部分添加这些变量
    private bool showModelListPanel = false; // 控制模型列表面板的显示
    private Vector2 modelListScrollPosition = Vector2.zero; // 模型列表滚动位置

    // 在私有变量部分添加这些变量
    private List<string> existingModelFiles = new List<string>(); // 存储文件夹中已有的模型文件路径
    private List<bool> existingModelStates = new List<bool>(); // 存储已有模型文件的加载状态
    private bool showExistingModelsPanel = false; // 控制已有模型面板的显示
    private Vector2 existingModelsScrollPosition = Vector2.zero; // 已有模型列表滚动位置

    // 在私有变量部分添加
    [Header("模型布局设置")]
    public float modelSpacing = 3f; // 模型之间的间距
    private float maxModelSpacing = 10f; // 最大间距

    // 添加一个枚举来表示当前显示的面板
    // 修改枚举，添加服务器模型面板
    public enum RightPanelType
    {
        None,
        ExistingModels,
        ModelList,
        ServerModels  // 新增
    }


    // 添加私有变量
    private RightPanelType currentRightPanel = RightPanelType.None;


    // 在私有变量部分添加
    [Header("界面控制")]
    public KeyCode toggleUIKey = KeyCode.F1; // 快捷键
    private bool showUI = true; // 控制整个UI的显示状态


    // 在私有变量部分添加服务器模型相关变量
    private List<ServerModelInfo> serverModels = new List<ServerModelInfo>(); // 服务器模型列表
    private List<bool> serverModelStates = new List<bool>(); // 服务器模型下载状态
    private bool showServerModelsPanel = false; // 控制服务器模型面板显示
    private Vector2 serverModelsScrollPosition = Vector2.zero; // 服务器模型列表滚动位置
    private bool isLoadingServerModels = false; // 是否正在加载服务器模型列表


    // 添加服务器模型信息类
    // 修改服务器模型信息类
    [System.Serializable]
    public class ServerModelInfo
    {
        public string folder_id;
        public string filename;
        public long size;
        public float created_time;
        public float modified_time;
        public string download_url;
        public string input_image_url;        // 新增：输入图片URL
        public string input_image_filename;   // 新增：输入图片文件名
    }

    [System.Serializable]
    public class ServerModelsResponse
    {
        public bool success;
        public List<ServerModelInfo> models;
        public int total_count;
        public string error;
    }

    // 在私有变量部分添加图片缓存相关变量
    private Dictionary<string, Texture2D> serverImageCache = new Dictionary<string, Texture2D>(); // 服务器图片缓存
    private Dictionary<string, bool> imageLoadingStates = new Dictionary<string, bool>(); // 图片加载状态
    private int previewImageSize = 100; // 预览图片大小

    // Android图片选择相关设置
    [Header("Android图片选择设置")]
    [Tooltip("Android设备上图片的最大尺寸")]
    public int maxImageSize = 1024;
    // 图片选择状态相关变量
    private bool isSelectingImage = false;
    private string imageSelectionStatus = "准备选择图片";
    [Tooltip("是否支持选择多张图片，对于VR一定要勾选")]
    public bool enableMultipleImageSelection =true;

    /// <summary>
    /// 加载服务器模型的预览图片
    /// </summary>
    IEnumerator LoadServerModelImage(string imageUrl, string cacheKey)
    {
        if (string.IsNullOrEmpty(imageUrl) || imageLoadingStates.ContainsKey(cacheKey))
            yield break;

        imageLoadingStates[cacheKey] = true;

        string fullUrl = $"{serverUrl}{imageUrl}";
        Debug.Log($"开始加载服务器图片: {fullUrl}");

        using (UnityWebRequest request = UnityWebRequestTexture.GetTexture(fullUrl))
        {
            request.timeout = 30;
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                try
                {
                    Texture2D texture = DownloadHandlerTexture.GetContent(request);
                    if (texture != null)
                    {
                        serverImageCache[cacheKey] = texture;
                        Debug.Log($"服务器图片加载成功: {cacheKey}");
                    }
                }
                catch (Exception e)
                {
                    Debug.LogError($"处理服务器图片失败: {e.Message}");
                }
            }
            else
            {
                Debug.LogError($"加载服务器图片失败: {request.error}");
            }

            imageLoadingStates.Remove(cacheKey);
        }
    }

    /// <summary>
    /// 获取或加载服务器模型预览图片
    /// </summary>
    Texture2D GetServerModelPreviewImage(ServerModelInfo model)
    {
        if (string.IsNullOrEmpty(model.input_image_url))
            return null;

        string cacheKey = $"{model.folder_id}_preview";

        // 如果已经缓存，直接返回
        if (serverImageCache.ContainsKey(cacheKey))
        {
            return serverImageCache[cacheKey];
        }

        // 如果没有在加载中，开始加载
        if (!imageLoadingStates.ContainsKey(cacheKey))
        {
            StartCoroutine(LoadServerModelImage(model.input_image_url, cacheKey));
        }

        return null; // 加载中返回null
    }




    /// <summary>
    /// 获取当前使用的下载文件夹路径
    /// </summary>
    /// <returns>下载文件夹的完整路径</returns>
    /// 
    // 1. 修改GetDownloadFolderPath方法，支持Android
    private string GetDownloadFolderPath()
    {
        if (useRelativePath)
        {
            string folderPath;

#if UNITY_ANDROID && !UNITY_EDITOR
        // Android平台使用persistentDataPath
        folderPath = Path.Combine(Application.persistentDataPath, relativeDownloadFolder);
#elif UNITY_EDITOR
            // 编辑器模式
            string executablePath = Directory.GetParent(Application.dataPath).FullName;
            folderPath = Path.Combine(executablePath, relativeDownloadFolder);
#else
        // 其他平台（Windows等）
        string executablePath = Directory.GetParent(Application.dataPath).FullName;
        folderPath = Path.Combine(executablePath, relativeDownloadFolder);
#endif

            return folderPath;
        }
        else
        {
            // 绝对路径模式在Android上不推荐使用
#if UNITY_ANDROID && !UNITY_EDITOR
        Debug.LogWarning("Android平台不建议使用绝对路径，自动切换到相对路径模式");
        return Path.Combine(Application.persistentDataPath, relativeDownloadFolder);
#else
            return absoluteDownloadFolder;
#endif
        }
    }



    /// <summary>
    /// 确保下载文件夹存在
    /// </summary>
    private void EnsureDownloadFolderExists()
    {
        currentDownloadFolder = GetDownloadFolderPath();

        try
        {
            if (!Directory.Exists(currentDownloadFolder))
            {
                Directory.CreateDirectory(currentDownloadFolder);
                Debug.Log($"创建下载文件夹: {currentDownloadFolder}");
            }
            else
            {
                Debug.Log($"使用下载文件夹: {currentDownloadFolder}");
            }

            // 扫描已有的模型文件
            ScanExistingModelFiles();
        }
        catch (Exception e)
        {
            Debug.LogError($"创建下载文件夹失败: {e.Message}");
            lastError = $"创建下载文件夹失败: {e.Message}";
        }
    }

    /// <summary>
    /// 重新分布所有可见模型的位置
    /// </summary>
    void RedistributeModelPositions()
    {
        // 获取所有可见的模型
        List<GameObject> visibleModels = new List<GameObject>();
        for (int i = 0; i < allModels.Count; i++)
        {
            if (allModels[i].modelObject != null && modelToggleStates[i])
            {
                visibleModels.Add(allModels[i].modelObject);
            }
        }

        if (visibleModels.Count == 0) return;

        if (visibleModels.Count == 1)
        {
            // 只有一个模型时，放在原点
            visibleModels[0].transform.position = modelParent.position;
        }
        else
        {
            // 多个模型时，沿X轴均匀分布
            float totalWidth = (visibleModels.Count - 1) * modelSpacing;
            float startX = -totalWidth / 2f;

            for (int i = 0; i < visibleModels.Count; i++)
            {
                Vector3 newPosition = modelParent.position;
                newPosition.x = startX + (i * modelSpacing);
                visibleModels[i].transform.position = newPosition;
            }
        }

        Debug.Log($"重新分布了 {visibleModels.Count} 个模型的位置，间距: {modelSpacing}");
    }

    /// <summary>
    /// 显示所有模型并重新分布位置
    /// </summary>
    void ShowAllModelsWithDistribution()
    {
        // 显示所有模型
        for (int i = 0; i < allModels.Count; i++)
        {
            if (allModels[i].modelObject != null)
            {
                allModels[i].modelObject.SetActive(true);
                modelToggleStates[i] = true;
            }
        }

        // 重新分布位置
        RedistributeModelPositions();
    }

    /// <summary>
    /// 隐藏所有模型
    /// </summary>
    void HideAllModels()
    {
        for (int i = 0; i < allModels.Count; i++)
        {
            if (allModels[i].modelObject != null)
            {
                allModels[i].modelObject.SetActive(false);
                modelToggleStates[i] = false;
            }
        }
    }

    /// <summary>
    /// 加载服务器模型列表
    /// </summary>
    IEnumerator LoadServerModelsList()
    {
        isLoadingServerModels = true;

        using (UnityWebRequest request = UnityWebRequest.Get($"{serverUrl}/list_models"))
        {
            request.timeout = 30;
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                try
                {
                    var response = JsonConvert.DeserializeObject<ServerModelsResponse>(request.downloadHandler.text);

                    if (response.success)
                    {
                        serverModels.Clear();
                        serverModelStates.Clear();

                        serverModels.AddRange(response.models);

                        // 初始化下载状态
                        for (int i = 0; i < serverModels.Count; i++)
                        {
                            serverModelStates.Add(false);
                        }

                        Debug.Log($"加载了 {serverModels.Count} 个服务器模型");
                    }
                    else
                    {
                        lastError = $"获取服务器模型列表失败: {response.error}";
                    }
                }
                catch (Exception e)
                {
                    lastError = $"解析服务器模型列表失败: {e.Message}";
                }
            }
            else
            {
                lastError = $"请求服务器模型列表失败: {request.error}";
            }
        }

        isLoadingServerModels = false;
    }

    /// <summary>
    /// 绘制服务器模型面板
    /// </summary>
    /// <summary>
    /// 绘制服务器模型面板（带图片预览）
    /// </summary>
    void DrawServerModelsPanel()
    {
        // 计算面板位置和大小
        float panelWidth = 450f; // 增加宽度以容纳图片
        float panelHeight = Screen.height - 40f;
        float panelX = Screen.width - panelWidth - 20f;
        float panelY = 20f;

        // 创建面板背景
        GUI.Box(new Rect(panelX - 10, panelY - 10, panelWidth + 20, panelHeight + 20), "");

        GUILayout.BeginArea(new Rect(panelX, panelY, panelWidth, panelHeight));

        // 面板标题
        GUILayout.BeginVertical(boxStyle);
        GUILayout.BeginHorizontal();
        GUILayout.Label($"服务器模型 ({serverModels.Count}个)", titleStyle);

        // 关闭按钮
        if (GUILayout.Button("×", buttonStyle, GUILayout.Width(25), GUILayout.Height(25)))
        {
            showServerModelsPanel = false;
            currentRightPanel = RightPanelType.None;
        }
        GUILayout.EndHorizontal();
        GUILayout.EndVertical();

        GUILayout.Space(5);

        // 操作按钮区域
        GUILayout.BeginVertical(boxStyle);
        GUILayout.BeginHorizontal();

        GUI.enabled = !isLoadingServerModels;
        if (GUILayout.Button("刷新列表", buttonStyle))
        {
            StartCoroutine(LoadServerModelsList());
        }

        if (GUILayout.Button("下载全部", buttonStyle))
        {
            DownloadAllServerModels();
        }

        if (GUILayout.Button("清理图片缓存", buttonStyle))
        {
            ClearImageCache();
        }
        GUI.enabled = true;

        GUILayout.EndHorizontal();
        GUILayout.EndVertical();

        GUILayout.Space(5);

        if (isLoadingServerModels)
        {
            GUILayout.Label("正在加载服务器模型列表...", labelStyle);
        }
        else
        {
            // 服务器模型列表滚动区域
            serverModelsScrollPosition = GUILayout.BeginScrollView(serverModelsScrollPosition);

            for (int i = 0; i < serverModels.Count; i++)
            {
                var model = serverModels[i];

                GUILayout.BeginVertical(boxStyle);

                // 水平布局：左侧图片，右侧信息
                GUILayout.BeginHorizontal();

                // 左侧：预览图片
                GUILayout.BeginVertical(GUILayout.Width(previewImageSize + 10));

                Texture2D previewImage = GetServerModelPreviewImage(model);
                if (previewImage != null)
                {
                    // 计算显示尺寸，保持宽高比
                    float aspectRatio = (float)previewImage.width / previewImage.height;
                    float displayWidth = previewImageSize;
                    float displayHeight = previewImageSize / aspectRatio;

                    if (displayHeight > previewImageSize)
                    {
                        displayHeight = previewImageSize;
                        displayWidth = previewImageSize * aspectRatio;
                    }

                    GUILayout.Box(previewImage, GUILayout.Width(displayWidth), GUILayout.Height(displayHeight));

                    // 图片信息
                    GUIStyle smallLabelStyle = new GUIStyle(labelStyle) { fontSize = 8 };
                    GUILayout.Label($"{previewImage.width}x{previewImage.height}", smallLabelStyle);
                }
                else
                {
                    // 显示加载中或无图片的占位符
                    string cacheKey = $"{model.folder_id}_preview";
                    if (imageLoadingStates.ContainsKey(cacheKey))
                    {
                        GUILayout.Box("加载中...", GUILayout.Width(previewImageSize), GUILayout.Height(previewImageSize));
                    }
                    else if (!string.IsNullOrEmpty(model.input_image_url))
                    {
                        GUILayout.Box("点击加载", GUILayout.Width(previewImageSize), GUILayout.Height(previewImageSize));
                        if (GUILayout.Button("加载图片", buttonStyle, GUILayout.Width(previewImageSize)))
                        {
                            StartCoroutine(LoadServerModelImage(model.input_image_url, cacheKey));
                        }
                    }
                    else
                    {
                        GUILayout.Box("无预览图", GUILayout.Width(previewImageSize), GUILayout.Height(previewImageSize));
                    }
                }

                GUILayout.EndVertical();

                GUILayout.Space(10);

                // 右侧：模型信息
                GUILayout.BeginVertical();

                // 模型基本信息
                GUILayout.Label($"#{i + 1} {model.filename}", labelStyle);
                GUILayout.Label($"文件夹: {model.folder_id.Substring(0, 8)}...", labelStyle);
                GUILayout.Label($"大小: {(model.size / 1024f):F1} KB", labelStyle);

                // 时间信息
                DateTime createTime = DateTimeOffset.FromUnixTimeSeconds((long)model.created_time).DateTime;
                DateTime modifyTime = DateTimeOffset.FromUnixTimeSeconds((long)model.modified_time).DateTime;
                GUILayout.Label($"创建: {createTime:yyyy/MM/dd HH:mm}", labelStyle);
                GUILayout.Label($"修改: {modifyTime:yyyy/MM/dd HH:mm}", labelStyle);

                // 图片信息
                if (!string.IsNullOrEmpty(model.input_image_filename))
                {
                    GUILayout.Label($"原图: {model.input_image_filename}", labelStyle);
                }

                GUILayout.Space(5);

                // 操作按钮
                GUILayout.BeginHorizontal();

                if (serverModelStates[i])
                {
                    GUI.color = Color.green;
                    GUILayout.Label("已下载", labelStyle, GUILayout.Width(60));
                    GUI.color = Color.white;
                }
                else
                {
                    if (GUILayout.Button("下载模型", buttonStyle, GUILayout.Width(80)))
                    {
                        StartCoroutine(DownloadServerModel(i));
                    }
                }

                if (GUILayout.Button("下载并加载", buttonStyle, GUILayout.Width(90)))
                {
                    StartCoroutine(DownloadAndLoadServerModel(i));
                }

                GUILayout.EndHorizontal();

                // 如果有预览图，添加下载原图按钮
                if (!string.IsNullOrEmpty(model.input_image_url))
                {
                    GUILayout.BeginHorizontal();
                    if (GUILayout.Button("下载原图", buttonStyle, GUILayout.Width(80)))
                    {
                        StartCoroutine(DownloadServerModelImage(i));
                    }
                    if (GUILayout.Button("查看大图", buttonStyle, GUILayout.Width(80)))
                    {
                        ShowImageFullscreen(model);
                    }
                    GUILayout.EndHorizontal();
                }

                GUILayout.EndVertical();

                GUILayout.EndHorizontal();

                GUILayout.EndVertical();
                GUILayout.Space(5);
            }

            GUILayout.EndScrollView();
        }

        GUILayout.EndArea();
    }

    /// <summary>
    /// 下载服务器模型的原始图片
    /// </summary>
    IEnumerator DownloadServerModelImage(int index)
    {
        if (index >= 0 && index < serverModels.Count)
        {
            var model = serverModels[index];
            if (string.IsNullOrEmpty(model.input_image_url))
            {
                Debug.LogWarning("该模型没有关联的输入图片");
                yield break;
            }

            string fullUrl = $"{serverUrl}{model.input_image_url}";
            string filename = model.input_image_filename ?? "input_image.png";
            string uniqueFilename = GenerateUniqueFilename(filename);
            string localPath = Path.Combine(currentDownloadFolder, uniqueFilename);

            Debug.Log($"开始下载服务器模型图片: {fullUrl} -> {localPath}");

            using (UnityWebRequest request = UnityWebRequest.Get(fullUrl))
            {
                request.timeout = 60;
                yield return request.SendWebRequest();

                if (request.result == UnityWebRequest.Result.Success)
                {
                    try
                    {
                        File.WriteAllBytes(localPath, request.downloadHandler.data);
                        Debug.Log($"服务器模型图片下载成功: {localPath}");
                    }
                    catch (Exception e)
                    {
                        lastError = $"保存服务器模型图片失败: {e.Message}";
                        Debug.LogError(lastError);
                    }
                }
                else
                {
                    lastError = $"下载服务器模型图片失败: {request.error}";
                    Debug.LogError(lastError);
                }
            }
        }
    }

    /// <summary>
    /// 显示图片全屏预览（简单实现）
    /// </summary>
    void ShowImageFullscreen(ServerModelInfo model)
    {
        string cacheKey = $"{model.folder_id}_preview";
        if (serverImageCache.ContainsKey(cacheKey))
        {
            Texture2D texture = serverImageCache[cacheKey];
            Debug.Log($"显示全屏图片: {model.input_image_filename} ({texture.width}x{texture.height})");
            // 这里可以实现一个全屏图片查看器，或者简单地在控制台输出信息
            // 由于Unity IMGUI的限制，全屏显示需要更复杂的实现
        }
    }

    /// <summary>
    /// 清理图片缓存
    /// </summary>
    void ClearImageCache()
    {
        foreach (var texture in serverImageCache.Values)
        {
            if (texture != null)
            {
                DestroyImmediate(texture);
            }
        }
        serverImageCache.Clear();
        imageLoadingStates.Clear();
        Debug.Log("已清理图片缓存");
    }



    /// <summary>
    /// 下载服务器模型
    /// </summary>
    IEnumerator DownloadServerModel(int index)
    {
        if (index >= 0 && index < serverModels.Count)
        {
            var model = serverModels[index];
            string fullUrl = $"{serverUrl}{model.download_url}";
            string uniqueFilename = GenerateUniqueFilename(model.filename);
            string localPath = Path.Combine(currentDownloadFolder, uniqueFilename);

            Debug.Log($"开始下载服务器模型: {fullUrl} -> {localPath}");

            using (UnityWebRequest request = UnityWebRequest.Get(fullUrl))
            {
                request.timeout = 300;
                yield return request.SendWebRequest();

                if (request.result == UnityWebRequest.Result.Success)
                {
                    try
                    {
                        File.WriteAllBytes(localPath, request.downloadHandler.data);
                        Debug.Log($"服务器模型下载成功: {localPath}");

                        serverModelStates[index] = true;

                        // 刷新本地文件列表
                        ScanExistingModelFiles();
                    }
                    catch (Exception e)
                    {
                        lastError = $"保存服务器模型失败: {e.Message}";
                        Debug.LogError(lastError);
                    }
                }
                else
                {
                    lastError = $"下载服务器模型失败: {request.error}";
                    Debug.LogError(lastError);
                }
            }
        }
    }

    /// <summary>
    /// 下载并加载服务器模型
    /// </summary>
    IEnumerator DownloadAndLoadServerModel(int index)
    {
        if (index >= 0 && index < serverModels.Count)
        {
            var model = serverModels[index];
            string fullUrl = $"{serverUrl}{model.download_url}";
            string uniqueFilename = GenerateUniqueFilename(model.filename);
            string localPath = Path.Combine(currentDownloadFolder, uniqueFilename);

            Debug.Log($"开始下载并加载服务器模型: {fullUrl} -> {localPath}");

            using (UnityWebRequest request = UnityWebRequest.Get(fullUrl))
            {
                request.timeout = 300;
                yield return request.SendWebRequest();

                if (request.result == UnityWebRequest.Result.Success)
                {
                    try
                    {
                        File.WriteAllBytes(localPath, request.downloadHandler.data);
                        Debug.Log($"服务器模型下载成功: {localPath}");

                        serverModelStates[index] = true;

                        // 刷新本地文件列表
                        ScanExistingModelFiles();

                        // 等待文件写入完成后加载模型
                        yield return new WaitForSeconds(0.5f);
                        LoadModelIntoScene(localPath);
                    }
                    finally { }
                }
                else
                {
                    lastError = $"下载服务器模型失败: {request.error}";
                    Debug.LogError(lastError);
                }
            }
        }
    }

    /// <summary>
    /// 下载所有服务器模型
    /// </summary>
    void DownloadAllServerModels()
    {
        for (int i = 0; i < serverModels.Count; i++)
        {
            if (!serverModelStates[i])
            {
                StartCoroutine(DownloadServerModel(i));
            }
        }
    }




    void Start()
    {
        // 确保下载文件夹存在
        EnsureDownloadFolderExists();

        // 扫描已有的模型文件
        ScanExistingModelFiles();

        // 如果没有指定模型父对象，创建一个
        if (modelParent == null)
        {
            GameObject parentObj = new GameObject("ModelParent");
            modelParent = parentObj.transform;
            modelParent.position = Vector3.zero;
        }

        // 启动时检查服务器连接
        StartCoroutine(CheckServerConnection());
    }


    void Update()
    {
        // 快捷键控制UI显示/隐藏
        if (Input.GetKeyDown(toggleUIKey))
        {
            showUI = !showUI;

            // 如果隐藏UI，同时关闭所有右侧面板
            if (!showUI)
            {
                showExistingModelsPanel = false;
                showModelListPanel = false;
                currentRightPanel = RightPanelType.None;
            }
        }

        // 旋转所有激活的模型
        foreach (var modelInfo in allModels)
        {
            if (modelInfo.modelObject != null && modelInfo.modelObject.activeInHierarchy)
            {
                modelInfo.modelObject.transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime);
            }
        }
    }



    void InitializeStyles()
    {
        if (stylesInitialized) return;

        titleStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 16,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleCenter
        };

        buttonStyle = new GUIStyle(GUI.skin.button)
        {
            fontSize = 11,
            padding = new RectOffset(8, 8, 4, 4)
        };

        boxStyle = new GUIStyle(GUI.skin.box)
        {
            padding = new RectOffset(8, 8, 8, 8)
        };

        labelStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 10,
            wordWrap = true
        };

        stylesInitialized = true;
    }

    void OnGUI()
    {
        InitializeStyles();

        // 在屏幕右上角显示UI控制按钮（始终显示）
        float toggleButtonWidth = 100f;
        float toggleButtonHeight = 30f;
        float toggleButtonX = Screen.width - toggleButtonWidth - 10f;
        float toggleButtonY = 10f;

        // UI控制按钮的样式
        GUIStyle toggleButtonStyle = new GUIStyle(buttonStyle)
        {
            fontSize = 12,
            fontStyle = FontStyle.Bold
        };

        // 设置按钮颜色
        GUI.color = showUI ? Color.green : Color.red;
        if (GUI.Button(new Rect(toggleButtonX, toggleButtonY, toggleButtonWidth, toggleButtonHeight),
                       showUI ? "隐藏界面" : "显示界面", toggleButtonStyle))
        {
            showUI = !showUI;

            // 如果隐藏UI，同时关闭所有右侧面板
            if (!showUI)
            {
                showExistingModelsPanel = false;
                showModelListPanel = false;
                currentRightPanel = RightPanelType.None;
            }
        }
        GUI.color = Color.white;

        // 显示快捷键提示（小字体，半透明）
        GUIStyle hintStyle = new GUIStyle(labelStyle)
        {
            fontSize = 8,
            alignment = TextAnchor.MiddleRight
        };
        GUI.color = new Color(1f, 1f, 1f, 0.7f);
        GUI.Label(new Rect(toggleButtonX - 50f, toggleButtonY + toggleButtonHeight + 2f, 150f, 15f),
                  $"快捷键: {toggleUIKey}", hintStyle);
        GUI.color = Color.white;

        // 只有在showUI为true时才显示主界面
        if (!showUI) return;

        // 原有的界面代码
        // 左侧界面 - 占据屏幕左侧五分之一
        float panelWidth = Screen.width / 5f;
        GUILayout.BeginArea(new Rect(10, 10, panelWidth - 20, Screen.height - 20));
        scrollPosition = GUILayout.BeginScrollView(scrollPosition);

        // 标题
        GUILayout.Label("Unity SuperXR图片AI建模", titleStyle);
        GUILayout.Space(10);

        // 文件路径设置区域
        DrawPathSettings();
        GUILayout.Space(8);

        // 服务器状态区域
        DrawServerStatus();
        GUILayout.Space(8);

        // 图片选择区域
        DrawImageSelection();
        GUILayout.Space(8);

        // 图片预览区域
        if (!string.IsNullOrEmpty(selectedImagePath))
        {
            DrawImagePreview();
            GUILayout.Space(8);
        }

        // 参数设置区域
        DrawParameterSettings();
        GUILayout.Space(8);

        // 生成控制区域
        DrawGenerationControls();
        GUILayout.Space(8);

        // 进度显示区域
        if (isGenerating)
        {
            DrawProgressDisplay();
            GUILayout.Space(8);
        }

        // 结果显示区域
        if (lastResult != null)
        {
            DrawResultDisplay();
            GUILayout.Space(8);
        }

        // 错误显示区域
        if (!string.IsNullOrEmpty(lastError))
        {
            DrawErrorDisplay();
        }

        GUILayout.EndScrollView();
        GUILayout.EndArea();

        // 右侧面板显示逻辑 - 使用枚举控制，确保只显示一个面板
        switch (currentRightPanel)
        {
            case RightPanelType.ExistingModels:
                if (existingModelFiles.Count > 0)
                    DrawExistingModelsPanel();
                break;
            case RightPanelType.ModelList:
                if (allModels.Count > 0)
                    DrawModelListPanel();
                break;
            // 在OnGUI方法的switch语句中添加
            case RightPanelType.ServerModels:
                if (serverModels.Count > 0)
                    DrawServerModelsPanel();
                break;
            case RightPanelType.None:
            default:
                // 不显示任何右侧面板
                break;
        }
    }


    void DrawExistingModelsPanel()
    {
        // 计算面板位置和大小
        float panelWidth = 350f;
        float panelHeight = Screen.height - 40f;
        float panelX = Screen.width - panelWidth - 20f;
        float panelY = 20f;

        // 创建面板背景
        GUI.Box(new Rect(panelX - 10, panelY - 10, panelWidth + 20, panelHeight + 20), "");

        GUILayout.BeginArea(new Rect(panelX, panelY, panelWidth, panelHeight));

        // 面板标题
        GUILayout.BeginVertical(boxStyle);
        GUILayout.BeginHorizontal();
        GUILayout.Label($"文件夹模型 ({existingModelFiles.Count}个)", titleStyle);

        // 关闭按钮
        if (GUILayout.Button("×", buttonStyle, GUILayout.Width(25), GUILayout.Height(25)))
        {
            showExistingModelsPanel = false;
        }
        GUILayout.EndHorizontal();
        GUILayout.EndVertical();

        GUILayout.Space(5);

        // 操作按钮区域
        GUILayout.BeginVertical(boxStyle);
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("刷新列表", buttonStyle))
        {
            ScanExistingModelFiles();
        }
        //if (GUILayout.Button("全部加载", buttonStyle))
        //{
        //    LoadAllExistingModels();
        //}
        GUILayout.EndHorizontal();
        GUILayout.EndVertical();

        GUILayout.Space(5);

        // 模型文件列表滚动区域
        existingModelsScrollPosition = GUILayout.BeginScrollView(existingModelsScrollPosition);

        for (int i = 0; i < existingModelFiles.Count; i++)
        {
            GUILayout.BeginVertical(boxStyle);

            string fileName = Path.GetFileName(existingModelFiles[i]);

            // 文件名和信息
            GUILayout.Label($"#{i + 1} {fileName}", labelStyle);

            // 简化的文件信息显示
            if (File.Exists(existingModelFiles[i]))
            {
                try
                {
                    long fileSize = new System.IO.FileInfo(existingModelFiles[i]).Length;
                    DateTime fileTime = File.GetLastWriteTime(existingModelFiles[i]);
                    GUILayout.Label($"大小: {(fileSize / 1024f):F1} KB", labelStyle);
                    GUILayout.Label($"修改: {fileTime:yyyy/MM/dd HH:mm}", labelStyle);
                }
                catch
                {
                    GUILayout.Label("文件信息获取失败", labelStyle);
                }
            }
            else
            {
                GUILayout.Label("文件不存在", labelStyle);
            }

            GUILayout.Space(3);

            // 加载状态和按钮
            GUILayout.BeginHorizontal();

            if (existingModelStates[i])
            {
                GUI.color = Color.green;
                GUILayout.Label("已加载", labelStyle, GUILayout.Width(50));
                GUI.color = Color.white;

                if (GUILayout.Button("卸载", buttonStyle, GUILayout.Width(60)))
                {
                    UnloadExistingModel(i);
                }
            }
            else
            {
                GUI.color = Color.gray;
                GUILayout.Label("未加载", labelStyle, GUILayout.Width(50));
                GUI.color = Color.white;

                if (GUILayout.Button("加载", buttonStyle, GUILayout.Width(60)))
                {
                    LoadExistingModel(i);
                }
            }

            //// 删除文件按钮
            //GUI.color = Color.red;
            //if (GUILayout.Button("删除文件", buttonStyle, GUILayout.Width(70)))
            //{
            //    DeleteExistingModelFile(i);
            //    break; // 跳出循环，因为列表已改变
            //}
            GUI.color = Color.white;

            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUILayout.Space(3);
        }

        GUILayout.EndScrollView();

        GUILayout.EndArea();
    }


    /// <summary>
    /// 加载指定的已有模型文件
    /// </summary>
    void LoadExistingModel(int index)
    {
        if (index >= 0 && index < existingModelFiles.Count)
        {
            string filePath = existingModelFiles[index];
            if (File.Exists(filePath))
            {
                StartCoroutine(LoadExistingModelCoroutine(filePath, index));
            }
            else
            {
                Debug.LogError($"文件不存在: {filePath}");
                // 重新扫描文件列表
                ScanExistingModelFiles();
            }
        }
    }

    /// <summary>
    /// 卸载指定的已有模型
    /// </summary>
    // 修改后的 UnloadExistingModel 方法（保持原有逻辑，确保状态同步）
    void UnloadExistingModel(int index)
    {
        if (index >= 0 && index < existingModelFiles.Count)
        {
            string filePath = existingModelFiles[index];

            // 在已加载模型列表中查找并移除
            for (int i = allModels.Count - 1; i >= 0; i--)
            {
                if (allModels[i].filePath == filePath)
                {
                    if (allModels[i].modelObject != null)
                    {
                        if (allModels[i].modelObject == currentModel)
                        {
                            currentModel = null;
                        }
                        DestroyImmediate(allModels[i].modelObject);
                    }
                    allModels.RemoveAt(i);
                    modelToggleStates.RemoveAt(i);
                    break;
                }
            }

            existingModelStates[index] = false;
            Debug.Log($"已卸载模型: {Path.GetFileName(filePath)}");

            // 重新分布剩余模型的位置
            RedistributeModelPositions();
        }
    }
    /// <summary>
    /// 加载所有已有模型文件
    /// </summary>
    void LoadAllExistingModels()
    {
        for (int i = 0; i < existingModelFiles.Count; i++)
        {
            if (!existingModelStates[i])
            {
                LoadExistingModel(i);
            }
        }
    }

    /// <summary>
    /// 删除指定的模型文件
    /// </summary>
    void DeleteExistingModelFile(int index)
    {
        if (index >= 0 && index < existingModelFiles.Count)
        {
            string filePath = existingModelFiles[index];
            string fileName = Path.GetFileName(filePath);

            // 这里可以添加确认对话框，但为了简化，直接删除
            try
            {
                // 先卸载模型（如果已加载）
                if (existingModelStates[index])
                {
                    UnloadExistingModel(index);
                }

                // 删除文件
                File.Delete(filePath);

                // 从列表中移除
                existingModelFiles.RemoveAt(index);
                existingModelStates.RemoveAt(index);

                Debug.Log($"已删除文件: {fileName}");

                // 如果没有文件了，关闭面板
                if (existingModelFiles.Count == 0)
                {
                    showExistingModelsPanel = false;
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"删除文件失败: {e.Message}");
                lastError = $"删除文件失败: {e.Message}";
            }
        }
    }

    /// <summary>
    /// 加载已有模型文件的协程
    /// </summary>
    IEnumerator LoadExistingModelCoroutine(string modelPath, int index)
    {
        Debug.Log($"开始加载已有模型: {modelPath}");

        // 使用GLTFast加载GLB文件
        var gltf = new GltfImport();

        // 将异步加载转换为协程
        var loadTask = gltf.LoadFile(modelPath);
        yield return new WaitUntil(() => loadTask.IsCompleted);

        if (loadTask.Result)
        {
            // 实例化模型
            var instantiateTask = gltf.InstantiateMainSceneAsync(modelParent);
            yield return new WaitUntil(() => instantiateTask.IsCompleted);

            if (instantiateTask.Result)
            {
                // 获取生成的模型对象
                GameObject loadedModel = modelParent.GetChild(modelParent.childCount - 1).gameObject;

                // 设置模型位置和缩放
                loadedModel.transform.localPosition = Vector3.zero;
                loadedModel.transform.localScale = modelScale;
                loadedModel.transform.rotation = Quaternion.identity; // 重置旋转

                // 计算模型边界并调整位置
                Renderer[] renderers = loadedModel.GetComponentsInChildren<Renderer>();
                if (renderers.Length > 0)
                {
                    Bounds bounds = renderers[0].bounds;
                    foreach (var renderer in renderers)
                    {
                        bounds.Encapsulate(renderer.bounds);
                    }

                    // 将模型中心移到原点
                    Vector3 centerOffset = bounds.center - modelParent.position;
                    loadedModel.transform.position -= centerOffset;
                }

                // 添加到模型列表
                string modelName = $"File_{Path.GetFileNameWithoutExtension(modelPath)}";
                loadedModel.name = modelName;

                ModelInfo newModel = new ModelInfo
                {
                    modelObject = loadedModel,
                    modelName = modelName,
                    filePath = modelPath
                };

                allModels.Add(newModel);
                modelToggleStates.Add(true); // 新模型默认显示

                // 隐藏其他所有模型，只显示最新的
                for (int i = 0; i < allModels.Count - 1; i++)
                {
                    if (allModels[i].modelObject != null)
                    {
                        allModels[i].modelObject.SetActive(false);
                        modelToggleStates[i] = false;
                    }
                }

                currentModel = loadedModel;
                existingModelStates[index] = true;

                Debug.Log($"已有模型加载成功: {modelName}");
                // 在成功加载模型后，添加这行
                RedistributeModelPositions();

                // 在Unity编辑器中刷新
#if UNITY_EDITOR
                UnityEditor.SceneView.RepaintAll();
#endif
            }
            else
            {
                Debug.LogError("已有模型实例化失败");
            }
        }
        else
        {
            Debug.LogError("已有GLB文件加载失败");
        }
    }




    /// <summary>
    /// 扫描下载文件夹中已有的模型文件
    /// </summary>
    void ScanExistingModelFiles()
    {
        existingModelFiles.Clear();
        existingModelStates.Clear();

        try
        {
            if (Directory.Exists(currentDownloadFolder))
            {
                // 搜索GLB文件
                string[] glbFiles = Directory.GetFiles(currentDownloadFolder, "*.glb", SearchOption.TopDirectoryOnly);

                foreach (string filePath in glbFiles)
                {
                    existingModelFiles.Add(filePath);
                    existingModelStates.Add(false); // 默认未加载
                }

                Debug.Log($"扫描到 {existingModelFiles.Count} 个已有的模型文件");
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"扫描模型文件失败: {e.Message}");
        }
    }


    void DrawModelListPanel()
    {
        // 计算面板位置和大小
        float panelWidth = 350f;
        float panelHeight = Screen.height - 40f;
        float panelX = Screen.width - panelWidth - 20f;
        float panelY = 20f;

        // 创建面板背景
        GUI.Box(new Rect(panelX - 10, panelY - 10, panelWidth + 20, panelHeight + 20), "");

        GUILayout.BeginArea(new Rect(panelX, panelY, panelWidth, panelHeight));

        // 面板标题
        GUILayout.BeginVertical(boxStyle);
        GUILayout.BeginHorizontal();
        GUILayout.Label($"已加载模型 ({allModels.Count}个)", titleStyle);

        // 关闭按钮
        if (GUILayout.Button("×", buttonStyle, GUILayout.Width(25), GUILayout.Height(25)))
        {
            showModelListPanel = false;
        }
        GUILayout.EndHorizontal();
        GUILayout.EndVertical();

        GUILayout.Space(5);

        // 模型间距控制
        GUILayout.BeginVertical(boxStyle);
        GUILayout.Label("模型布局设置");

        GUILayout.BeginHorizontal();
        GUILayout.Label("模型间距:", GUILayout.Width(80));
        float newSpacing = GUILayout.HorizontalSlider(modelSpacing, 0f, maxModelSpacing);
        if (Math.Abs(newSpacing - modelSpacing) > 0.01f)
        {
            modelSpacing = newSpacing;
            RedistributeModelPositions(); // 实时更新位置
        }
        GUILayout.Label(modelSpacing.ToString("F1"), GUILayout.Width(30));
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("重新分布", buttonStyle))
        {
            RedistributeModelPositions();
        }
        if (GUILayout.Button("重置间距", buttonStyle))
        {
            modelSpacing = 3f;
            RedistributeModelPositions();
        }
        GUILayout.EndHorizontal();

        GUILayout.EndVertical();

        GUILayout.Space(5);

        // 操作按钮区域
        GUILayout.BeginVertical(boxStyle);
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("全部显示", buttonStyle))
        {
            ShowAllModelsWithDistribution(); // 使用新的方法
        }
        if (GUILayout.Button("全部隐藏", buttonStyle))
        {
            HideAllModels();
        }
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("清除所有", buttonStyle))
        {
            ClearAllModels();
            showModelListPanel = false;
        }
        if (GUILayout.Button("刷新列表", buttonStyle))
        {
            // 可以添加刷新逻辑，比如检查模型对象是否还存在
            RefreshModelList();
        }
        GUILayout.EndHorizontal();
        GUILayout.EndVertical();

        GUILayout.Space(5);

        // 模型列表滚动区域
        modelListScrollPosition = GUILayout.BeginScrollView(modelListScrollPosition);

        for (int i = 0; i < allModels.Count; i++)
        {
            if (allModels[i].modelObject == null) continue;

            GUILayout.BeginVertical(boxStyle);

            // 模型名称和信息
            GUILayout.Label($"#{i + 1} {allModels[i].modelName}", labelStyle);

            if (!string.IsNullOrEmpty(allModels[i].filePath))
            {
                string fileName = Path.GetFileName(allModels[i].filePath);
                GUILayout.Label($"文件: {fileName}", labelStyle);
            }

            GUILayout.Space(3);

            // 显示/隐藏控制
            GUILayout.BeginHorizontal();

            bool isVisible = modelToggleStates[i];
            bool newVisible = GUILayout.Toggle(isVisible, isVisible ? "显示中" : "已隐藏", GUILayout.Width(80));

            if (newVisible != isVisible)
            {
                modelToggleStates[i] = newVisible;
                allModels[i].modelObject.SetActive(newVisible);

                // 如果切换了显示状态，重新分布位置
                RedistributeModelPositions();
            }

            // 聚焦到此模型按钮
            if (GUILayout.Button("聚焦", buttonStyle, GUILayout.Width(50)))
            {
                FocusOnModel(allModels[i].modelObject);
            }

            // 删除此模型按钮
            GUI.color = Color.red;
            if (GUILayout.Button("删除", buttonStyle, GUILayout.Width(50)))
            {
                RemoveModel(i);
                break; // 跳出循环，因为列表已改变
            }
            GUI.color = Color.white;

            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUILayout.Space(3);
        }

        GUILayout.EndScrollView();

        GUILayout.EndArea();
    }

    /// <summary>
    /// 聚焦到指定模型（将其他模型隐藏，只显示这个）
    /// </summary>
    void FocusOnModel(GameObject targetModel)
    {
        for (int i = 0; i < allModels.Count; i++)
        {
            if (allModels[i].modelObject != null)
            {
                bool shouldShow = allModels[i].modelObject == targetModel;
                allModels[i].modelObject.SetActive(shouldShow);
                modelToggleStates[i] = shouldShow;
            }
        }

        // 将聚焦的模型移到中心
        if (targetModel != null)
        {
            targetModel.transform.position = modelParent.position;
            currentModel = targetModel;
        }
    }

    /// <summary>
    /// 刷新模型列表，移除已被销毁的模型
    /// </summary>
    void RefreshModelList()
    {
        for (int i = allModels.Count - 1; i >= 0; i--)
        {
            if (allModels[i].modelObject == null)
            {
                allModels.RemoveAt(i);
                modelToggleStates.RemoveAt(i);
            }
        }

        Debug.Log($"刷新后模型列表包含 {allModels.Count} 个模型");
    }

    /// <summary>
    /// 移除指定索引的模型
    /// </summary>
    // 修改后的 RemoveModel 方法，也要同步状态
    void RemoveModel(int index)
    {
        if (index >= 0 && index < allModels.Count)
        {
            string filePath = allModels[index].filePath;

            if (allModels[index].modelObject != null)
            {
                if (allModels[index].modelObject == currentModel)
                {
                    currentModel = null;
                }
                DestroyImmediate(allModels[index].modelObject);
            }

            allModels.RemoveAt(index);
            modelToggleStates.RemoveAt(index);

            // 如果删除的模型来自文件，更新对应的文件状态
            if (!string.IsNullOrEmpty(filePath))
            {
                for (int i = 0; i < existingModelFiles.Count; i++)
                {
                    if (existingModelFiles[i] == filePath)
                    {
                        existingModelStates[i] = false;
                        break;
                    }
                }
            }

            // 重新分布剩余模型的位置
            RedistributeModelPositions();

            Debug.Log($"已删除模型 #{index + 1}");
        }
    }



    // 删除单个模型
    void RemoveSingleModel(int index)
    {
        if (index >= 0 && index < allModels.Count)
        {
            if (allModels[index].modelObject != null)
            {
                // 如果删除的是当前模型，更新currentModel引用
                if (allModels[index].modelObject == currentModel)
                {
                    currentModel = null;
                    // 尝试设置下一个激活的模型为当前模型
                    for (int i = 0; i < allModels.Count; i++)
                    {
                        if (i != index && allModels[i].modelObject != null && allModels[i].modelObject.activeInHierarchy)
                        {
                            currentModel = allModels[i].modelObject;
                            break;
                        }
                    }
                }

                DestroyImmediate(allModels[index].modelObject);
            }

            allModels.RemoveAt(index);
            modelToggleStates.RemoveAt(index);

            Debug.Log($"已删除模型 #{index + 1}");

            // 如果没有模型了，关闭面板
            if (allModels.Count == 0)
            {
                showModelListPanel = false;
            }
        }
    }

    // 显示所有模型
    void ShowAllModels()
    {
        for (int i = 0; i < allModels.Count; i++)
        {
            if (allModels[i].modelObject != null)
            {
                allModels[i].modelObject.SetActive(true);
                modelToggleStates[i] = true;
            }
        }
        ResetAllActiveModelsRotation();
        Debug.Log("已显示所有模型");
    }




    void DrawPathSettings()
    {
        GUILayout.BeginVertical(boxStyle);
        GUILayout.Label("文件路径设置");

        // 路径模式选择
        bool newUseRelativePath = GUILayout.Toggle(useRelativePath, "使用相对路径（推荐打包）");
        if (newUseRelativePath != useRelativePath)
        {
            useRelativePath = newUseRelativePath;
            EnsureDownloadFolderExists(); // 重新创建文件夹
        }

        if (useRelativePath)
        {
            // 相对路径设置
            GUILayout.BeginHorizontal();
            GUILayout.Label("文件夹名:", GUILayout.Width(80));
            string newRelativeFolder = GUILayout.TextField(relativeDownloadFolder);
            if (newRelativeFolder != relativeDownloadFolder)
            {
                relativeDownloadFolder = newRelativeFolder;
                EnsureDownloadFolderExists(); // 重新创建文件夹
            }
            GUILayout.EndHorizontal();
        }
        else
        {
            // 绝对路径设置
            GUILayout.Label("绝对路径:", labelStyle);
            string newAbsoluteFolder = GUILayout.TextField(absoluteDownloadFolder);
            if (newAbsoluteFolder != absoluteDownloadFolder)
            {
                absoluteDownloadFolder = newAbsoluteFolder;
                EnsureDownloadFolderExists(); // 重新创建文件夹
            }
        }

        // 显示当前使用的路径
        GUILayout.Space(5);
        GUILayout.Label("当前路径:", labelStyle);
        GUILayout.Label(currentDownloadFolder ?? "未设置", labelStyle);

        // 打开文件夹按钮
        if (!string.IsNullOrEmpty(currentDownloadFolder) && Directory.Exists(currentDownloadFolder))
        {
            if (GUILayout.Button("打开文件夹", buttonStyle))
            {
                OpenDownloadFolder();
            }
        }

        GUILayout.EndVertical();
    }

    void DrawServerStatus()
    {
        GUILayout.BeginVertical(boxStyle);
        GUILayout.Label("服务器状态");

        GUILayout.BeginHorizontal();
        GUILayout.Label($"地址: {serverUrl}", labelStyle);
        if (GUILayout.Button("测试连接", buttonStyle, GUILayout.Width(70)))
        {
            StartCoroutine(CheckServerConnection());
        }
        GUILayout.EndHorizontal();

        // 状态指示器
        GUI.color = isConnected ? Color.green : Color.red;
        GUILayout.Label($"状态: {connectionStatus}", labelStyle);
        GUI.color = Color.white;

        // 服务器信息
        if (serverInfo != null)
        {
            GUILayout.Label($"版本: {serverInfo.version}", labelStyle);
            GUILayout.Label($"纹理生成: {(serverInfo.features.texture_generation ? "支持" : "不支持")}", labelStyle);
        }

        GUILayout.EndVertical();
    }

    void DrawImageSelection()
    {
        GUILayout.BeginVertical(boxStyle);
        GUILayout.Label("图片选择");

        GUILayout.BeginHorizontal();
        GUILayout.Label($"已选择: {(string.IsNullOrEmpty(selectedImagePath) ? "无" : Path.GetFileName(selectedImagePath))}", labelStyle);
        if (GUILayout.Button("选择图片", buttonStyle, GUILayout.Width(70)))
        {
            SelectImage();
        }

#if UNITY_ANDROID
        // Android平台特有的选项
        GUILayout.Space(5);
        GUILayout.Label("Android/VR设置", labelStyle);

        enableMultipleImageSelection = GUILayout.Toggle(enableMultipleImageSelection, "支持多选图片");

        GUILayout.BeginHorizontal();
        GUILayout.Label("最大尺寸:", GUILayout.Width(80));
        string maxSizeStr = GUILayout.TextField(maxImageSize.ToString(), GUILayout.Width(80));
        if (int.TryParse(maxSizeStr, out int newMaxSize))
        {
            maxImageSize = newMaxSize;
        }
        GUILayout.EndHorizontal();

        // 显示图片选择状态
        if (isSelectingImage || !string.IsNullOrEmpty(imageSelectionStatus))
        {
            GUILayout.Space(3);
            GUILayout.Label($"状态: {imageSelectionStatus}", labelStyle);
        }
#endif

        GUILayout.EndHorizontal();

        GUILayout.EndVertical();
    }

    void DrawImagePreview()
    {
        GUILayout.BeginVertical(boxStyle);
        GUILayout.Label("图片预览");

        if (currentImageTexture != null)
        {
            // 计算显示尺寸，保持宽高比
            float aspectRatio = (float)currentImageTexture.width / currentImageTexture.height;
            float displayWidth = imagePreviewSize;
            float displayHeight = imagePreviewSize / aspectRatio;

            if (displayHeight > imagePreviewSize)
            {
                displayHeight = imagePreviewSize;
                displayWidth = imagePreviewSize * aspectRatio;
            }

            // 居中显示图片
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            GUILayout.Box(currentImageTexture, GUILayout.Width(displayWidth), GUILayout.Height(displayHeight));
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();

            GUILayout.Label($"尺寸: {currentImageTexture.width}x{currentImageTexture.height}", labelStyle);
        }
        else
        {
            GUILayout.Box("无预览", GUILayout.Width(imagePreviewSize), GUILayout.Height(imagePreviewSize));
        }

        GUILayout.EndVertical();
    }

    void DrawParameterSettings()
    {
        GUILayout.BeginVertical(boxStyle);
        GUILayout.Label("生成参数");

        // 基础参数
        GUILayout.BeginHorizontal();
        GUILayout.Label("生成步数:", GUILayout.Width(80));
        steps = (int)GUILayout.HorizontalSlider(steps, 10, 100);
        GUILayout.Label(steps.ToString(), GUILayout.Width(30));
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        GUILayout.Label("引导强度:", GUILayout.Width(80));
        guidanceScale = GUILayout.HorizontalSlider(guidanceScale, 1.0f, 20.0f);
        GUILayout.Label(guidanceScale.ToString("F1"), GUILayout.Width(30));
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        GUILayout.Label("随机种子:", GUILayout.Width(80));
        if (!randomizeSeed)
        {
            string seedStr = GUILayout.TextField(seed.ToString(), GUILayout.Width(80));
            if (int.TryParse(seedStr, out int newSeed))
            {
                seed = Mathf.Clamp(newSeed, 0, 9999999);
            }
        }
        else
        {
            GUILayout.Label("随机", GUILayout.Width(80));
        }
        GUILayout.EndHorizontal();

        randomizeSeed = GUILayout.Toggle(randomizeSeed, "随机化种子");
        removeBackground = GUILayout.Toggle(removeBackground, "移除背景");
        includeTexture = GUILayout.Toggle(includeTexture, "生成纹理");

        // 高级选项
        showAdvancedOptions = GUILayout.Toggle(showAdvancedOptions, "显示高级选项");

        if (showAdvancedOptions)
        {
            GUILayout.Space(5);
            GUILayout.Label("高级选项");

            GUILayout.BeginHorizontal();
            GUILayout.Label("八叉树分辨率:", GUILayout.Width(80));
            octreeResolution = (int)GUILayout.HorizontalSlider(octreeResolution, 64, 512);
            GUILayout.Label(octreeResolution.ToString(), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("处理块数:", GUILayout.Width(80));
            numChunks = (int)GUILayout.HorizontalSlider(numChunks, 50000, 500000);
            GUILayout.Label(numChunks.ToString(), GUILayout.Width(50));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("文件格式:", GUILayout.Width(80));
            string[] formats = { "glb", "obj", "ply", "stl" };
            int currentIndex = Array.IndexOf(formats, fileType);
            if (currentIndex == -1) currentIndex = 0;
            int newIndex = GUILayout.SelectionGrid(currentIndex, formats, 2);
            fileType = formats[newIndex];
            GUILayout.EndHorizontal();
        }

        GUILayout.EndVertical();
    }

    void DrawGenerationControls()
    {
        GUILayout.BeginVertical(boxStyle);
        GUILayout.Label("生成控制");

        GUI.enabled = !isGenerating && isConnected && !string.IsNullOrEmpty(selectedImagePath);
        if (GUILayout.Button("开始生成3D模型", buttonStyle, GUILayout.Height(35)))
        {
            StartCoroutine(GenerateModel());
        }
        GUI.enabled = true;

        if (isGenerating)
        {
            if (GUILayout.Button("取消生成", buttonStyle))
            {
                StopAllCoroutines();
                isGenerating = false;
                progressMessage = "生成已取消";
            }
        }

        // 模型控制
        if (currentModel != null)
        {
            GUILayout.Space(5);
            GUILayout.Label("模型控制");

            GUILayout.BeginHorizontal();
            GUILayout.Label("旋转速度:", GUILayout.Width(80));
            rotationSpeed = GUILayout.HorizontalSlider(rotationSpeed, 0f, 100f);
            GUILayout.Label(rotationSpeed.ToString("F0"), GUILayout.Width(30));
            GUILayout.EndHorizontal();

            if (GUILayout.Button("清除当前模型", buttonStyle))
            {
                ClearCurrentModel();
            }
        }

        // 在DrawGenerationControls方法的最后添加服务器模型管理
        if (isConnected)
        {
            GUILayout.Space(10);
            GUILayout.Label("服务器模型管理");

            GUILayout.BeginHorizontal();

            // 查看服务器模型按钮
            string serverButtonText = (currentRightPanel == RightPanelType.ServerModels) ? "隐藏服务器模型" : "查看服务器模型";
            if (GUILayout.Button(serverButtonText, buttonStyle))
            {
                if (currentRightPanel == RightPanelType.ServerModels)
                {
                    showServerModelsPanel = false;
                    currentRightPanel = RightPanelType.None;
                }
                else
                {
                    showServerModelsPanel = true;
                    showExistingModelsPanel = false;
                    showModelListPanel = false;
                    currentRightPanel = RightPanelType.ServerModels;

                    // 加载服务器模型列表
                    StartCoroutine(LoadServerModelsList());
                }
            }

            // 刷新服务器模型列表按钮
            GUI.enabled = !isLoadingServerModels;
            if (GUILayout.Button("刷新服务器列表", buttonStyle))
            {
                StartCoroutine(LoadServerModelsList());
            }
            GUI.enabled = true;

            GUILayout.EndHorizontal();

            if (isLoadingServerModels)
            {
                GUILayout.Label("正在加载服务器模型列表...", labelStyle);
            }
            else if (serverModels.Count > 0)
            {
                GUILayout.Label($"服务器模型: {serverModels.Count}个", labelStyle);
            }
        }

        // 已有模型文件管理
        if (existingModelFiles.Count > 0)
        {
            GUILayout.Space(10);
            GUILayout.Label($"文件夹模型 (共{existingModelFiles.Count}个文件)");

            GUILayout.BeginHorizontal();

            // 修改后的查看已有模型按钮逻辑
            string existingButtonText = (currentRightPanel == RightPanelType.ExistingModels) ? "隐藏文件列表" : "查看文件列表";
            if (GUILayout.Button(existingButtonText, buttonStyle))
            {
                if (currentRightPanel == RightPanelType.ExistingModels)
                {
                    // 当前显示文件列表，点击后隐藏
                    showExistingModelsPanel = false;
                    currentRightPanel = RightPanelType.None;
                }
                else
                {
                    // 当前不显示文件列表，点击后显示并关闭其他面板
                    showExistingModelsPanel = true;
                    showModelListPanel = false;
                    currentRightPanel = RightPanelType.ExistingModels;
                }
            }

            // 刷新文件列表按钮
            if (GUILayout.Button("刷新列表", buttonStyle))
            {
                ScanExistingModelFiles();
            }

            GUILayout.EndHorizontal();
        }
        else
        {
            // 如果没有找到文件，显示刷新按钮
            GUILayout.Space(10);
            GUILayout.Label("文件夹模型 (未找到GLB文件)");
            if (GUILayout.Button("刷新列表", buttonStyle))
            {
                ScanExistingModelFiles();
            }
        }

        // 已加载模型管理按钮区域
        if (allModels.Count > 0)
        {
            GUILayout.Space(10);
            GUILayout.Label($"已加载模型 (共{allModels.Count}个模型)");

            GUILayout.BeginHorizontal();

            // 修改后的显示/隐藏模型列表按钮逻辑
            string buttonText = (currentRightPanel == RightPanelType.ModelList) ? "隐藏模型列表" : "查看模型列表";
            if (GUILayout.Button(buttonText, buttonStyle))
            {
                if (currentRightPanel == RightPanelType.ModelList)
                {
                    // 当前显示模型列表，点击后隐藏
                    showModelListPanel = false;
                    currentRightPanel = RightPanelType.None;
                }
                else
                {
                    // 当前不显示模型列表，点击后显示并关闭其他面板
                    showModelListPanel = true;
                    showExistingModelsPanel = false;
                    currentRightPanel = RightPanelType.ModelList;
                }
            }

            // 清除所有模型按钮
            if (GUILayout.Button("清除所有模型", buttonStyle))
            {
                ClearAllModels();
                showModelListPanel = false; // 清除后自动隐藏面板
                if (currentRightPanel == RightPanelType.ModelList)
                {
                    currentRightPanel = RightPanelType.None;
                }
            }




            GUILayout.EndHorizontal();
        }

        GUILayout.EndVertical();
    }




    // 重置所有激活模型的旋转
    void ResetAllActiveModelsRotation()
    {
        foreach (var modelInfo in allModels)
        {
            if (modelInfo.modelObject != null && modelInfo.modelObject.activeInHierarchy)
            {
                modelInfo.modelObject.transform.rotation = Quaternion.identity;
            }
        }
    }

    // 清除所有模型
    // 修改后的 ClearAllModels 方法
    void ClearAllModels()
    {
        foreach (var modelInfo in allModels)
        {
            if (modelInfo.modelObject != null)
            {
                DestroyImmediate(modelInfo.modelObject);
            }
        }
        allModels.Clear();
        modelToggleStates.Clear();
        currentModel = null;

        // 重置所有已有模型文件的加载状态
        for (int i = 0; i < existingModelStates.Count; i++)
        {
            existingModelStates[i] = false;
        }

        Debug.Log("已清除所有模型并重置文件加载状态");
    }



    void DrawProgressDisplay()
    {
        GUILayout.BeginVertical(boxStyle);
        GUILayout.Label("生成进度");

        // 进度条
        Rect progressRect = GUILayoutUtility.GetRect(0, 20, GUILayout.ExpandWidth(true));
        GUI.Box(progressRect, "");
        GUI.Box(new Rect(progressRect.x, progressRect.y, progressRect.width * progress, progressRect.height), "", GUI.skin.button);

        GUILayout.Label($"{progressMessage} ({(progress * 100):F0}%)", labelStyle);

        GUILayout.EndVertical();
    }

    void DrawResultDisplay()
    {
        GUILayout.BeginVertical(boxStyle);
        GUILayout.Label("生成结果");

        GUILayout.Label($"种子: {lastResult.seed}", labelStyle);
        GUILayout.Label($"生成时间: {lastResult.stats.time.total:F1}秒", labelStyle);
        GUILayout.Label($"面数: {lastResult.stats.number_of_faces:N0}", labelStyle);
        GUILayout.Label($"顶点数: {lastResult.stats.number_of_vertices:N0}", labelStyle);

        if (lastResult.files != null)
        {
            GUILayout.Label("生成的文件:", labelStyle);
            foreach (var file in lastResult.files)
            {
                GUILayout.BeginHorizontal();
                GUILayout.Label($"• {file.Key}: {file.Value.filename}", labelStyle);
                if (GUILayout.Button("下载", buttonStyle, GUILayout.Width(50)))
                {
                    StartCoroutine(DownloadFile(file.Value.download_url, file.Value.filename));
                }
                GUILayout.EndHorizontal();
            }
        }

        GUILayout.EndVertical();
    }

    void DrawErrorDisplay()
    {
        GUILayout.BeginVertical(boxStyle);
        GUI.color = Color.red;
        GUILayout.Label("错误信息");
        GUI.color = Color.white;

        GUILayout.Label(lastError, labelStyle);

        if (GUILayout.Button("清除错误", buttonStyle, GUILayout.Width(70)))
        {
            lastError = "";
        }

        GUILayout.EndVertical();
    }

    /// <summary>
    /// 打开下载文件夹
    /// </summary>
    // 8. 修改OpenDownloadFolder方法，支持Android
    void OpenDownloadFolder()
    {
        try
        {
            if (Directory.Exists(currentDownloadFolder))
            {
#if UNITY_ANDROID && !UNITY_EDITOR
            // Android平台显示提示，因为无法直接打开文件管理器
            Debug.Log($"下载文件夹路径: {currentDownloadFolder}");
            lastError = $"文件保存在: {currentDownloadFolder}";
            
            // 可以尝试使用Android Intent（需要额外的插件或原生代码）
            // 这里提供一个简单的提示
#elif UNITY_EDITOR_WIN || UNITY_STANDALONE_WIN
                System.Diagnostics.Process.Start("explorer.exe", currentDownloadFolder);
#elif UNITY_EDITOR_OSX || UNITY_STANDALONE_OSX
            System.Diagnostics.Process.Start("open", currentDownloadFolder);
#elif UNITY_EDITOR_LINUX || UNITY_STANDALONE_LINUX
            System.Diagnostics.Process.Start("xdg-open", currentDownloadFolder);
#endif
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"打开文件夹失败: {e.Message}");
        }
    }

    void SelectImage()
    {
#if UNITY_EDITOR
        // 在编辑器中使用EditorUtility
        string path = UnityEditor.EditorUtility.OpenFilePanel("选择图片", "", "png,jpg,jpeg,gif,bmp,tiff,webp");
        if (!string.IsNullOrEmpty(path))
        {
            selectedImagePath = path;
            lastError = "";
            LoadImagePreview(path);
        }
#elif UNITY_ANDROID
    // Android平台使用NativeGallery（包括VR设备）
    if (enableMultipleImageSelection)
    {
        PickMultipleImages();
    }
    else
    {
        PickSingleImageFromGallery();
    }
#else
    // 其他平台使用SimpleFileBrowser
    FileBrowser.SetFilters(true, new FileBrowser.Filter("图片", ".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tiff", ".webp"));
    FileBrowser.SetDefaultFilter(".png");
    StartCoroutine(ShowLoadDialogCoroutine());
#endif
    }

#if UNITY_ANDROID
    /// <summary>
    /// 选择多张图片（Android/VR平台）
    /// </summary>
    public void PickMultipleImages()
    {
        if (NativeGallery.IsMediaPickerBusy())
        {
            UpdateImageSelectionStatus("正在选择图片，请稍候...");
            return;
        }

        if (!NativeGallery.CanSelectMultipleFilesFromGallery())
        {
            UpdateImageSelectionStatus("当前设备不支持选择多张图片，切换到单选模式");
            PickSingleImageFromGallery();
            return;
        }

        CheckPermissionAndPickImages();
    }

    /// <summary>
    /// 选择单张图片（Android/VR平台）
    /// </summary>
    void PickSingleImageFromGallery()
    {
        if (NativeGallery.IsMediaPickerBusy())
        {
            UpdateImageSelectionStatus("正在选择图片，请稍候...");
            return;
        }

        CheckPermissionAndPickSingleImage();
    }

    /// <summary>
    /// 检查权限并选择多张图片
    /// </summary>
    private void CheckPermissionAndPickImages()
    {
        bool hasPermission = NativeGallery.CheckPermission(NativeGallery.PermissionType.Read, NativeGallery.MediaType.Image);

        if (hasPermission)
        {
            PickImages();
        }
        else
        {
            UpdateImageSelectionStatus("请求权限中...");
            NativeGallery.RequestPermissionAsync(OnPermissionResultForMultiple, NativeGallery.PermissionType.Read, NativeGallery.MediaType.Image);
        }
    }

    /// <summary>
    /// 检查权限并选择单张图片
    /// </summary>
    private void CheckPermissionAndPickSingleImage()
    {
        bool hasPermission = NativeGallery.CheckPermission(NativeGallery.PermissionType.Read, NativeGallery.MediaType.Image);

        if (hasPermission)
        {
            PickSingleImage();
        }
        else
        {
            UpdateImageSelectionStatus("请求权限中...");
            NativeGallery.RequestPermissionAsync(OnPermissionResultForSingle, NativeGallery.PermissionType.Read, NativeGallery.MediaType.Image);
        }
    }

    /// <summary>
    /// 多选图片的权限请求结果回调
    /// </summary>
    private void OnPermissionResultForMultiple(NativeGallery.Permission permission)
    {
        if (permission == NativeGallery.Permission.Granted)
        {
            UpdateImageSelectionStatus("权限获取成功");
            PickImages();
        }
        else
        {
            UpdateImageSelectionStatus("权限被拒绝，无法访问相册");
            if (permission == NativeGallery.Permission.Denied)
            {
                UpdateImageSelectionStatus("权限被永久拒绝，请在设置中手动开启相册权限");
            }
        }
    }

    /// <summary>
    /// 单选图片的权限请求结果回调
    /// </summary>
    private void OnPermissionResultForSingle(NativeGallery.Permission permission)
    {
        if (permission == NativeGallery.Permission.Granted)
        {
            UpdateImageSelectionStatus("权限获取成功");
            PickSingleImage();
        }
        else
        {
            UpdateImageSelectionStatus("权限被拒绝，无法访问相册");
            if (permission == NativeGallery.Permission.Denied)
            {
                UpdateImageSelectionStatus("权限被永久拒绝，请在设置中手动开启相册权限");
            }
        }
    }

    /// <summary>
    /// 执行选择多张图片操作
    /// </summary>
    private void PickImages()
    {
        UpdateImageSelectionStatus("正在打开相册选择多张图片...");

        NativeGallery.GetImagesFromGallery((paths) =>
        {
            if (paths != null && paths.Length > 0)
            {
                UpdateImageSelectionStatus($"选择了 {paths.Length} 张图片");

                for (int i = 0; i < paths.Length; i++)
                {
                    Debug.Log($"图片 {i + 1}: {paths[i]}");
                }

                if (paths.Length > 0)
                {
                    selectedImagePath = paths[0];
                    LoadAndDisplaySelectedImage(paths[0]);
                }
            }
            else
            {
                UpdateImageSelectionStatus("已取消选择图片");
            }
        }, "选择图片", "image/*");
    }

    /// <summary>
    /// 执行选择单张图片操作
    /// </summary>
    private void PickSingleImage()
    {
        UpdateImageSelectionStatus("正在打开相册选择图片...");

        NativeGallery.GetImageFromGallery((path) =>
        {
            if (!string.IsNullOrEmpty(path))
            {
                selectedImagePath = path;
                UpdateImageSelectionStatus("图片选择成功");
                LoadAndDisplaySelectedImage(path);
            }
            else
            {
                UpdateImageSelectionStatus("已取消选择图片");
            }
        }, "选择图片", "image/*");
    }

    /// <summary>
    /// 加载并显示选择的图片
    /// </summary>
    private void LoadAndDisplaySelectedImage(string imagePath)
    {
        if (currentImageTexture != null)
        {
            DestroyImmediate(currentImageTexture);
            currentImageTexture = null;
        }

        currentImageTexture = NativeGallery.LoadImageAtPath(imagePath, maxImageSize, false, true, false);

        if (currentImageTexture != null)
        {
            UpdateImageSelectionStatus($"图片加载成功，尺寸: {currentImageTexture.width}x{currentImageTexture.height}");
            Debug.Log($"Android图片加载成功！尺寸: {currentImageTexture.width}x{currentImageTexture.height}");
            lastError = "";
        }
        else
        {
            UpdateImageSelectionStatus("图片加载失败");
            lastError = "图片加载失败";
            Debug.LogError("无法从路径加载纹理: " + imagePath);
        }
    }

    /// <summary>
    /// 更新图片选择状态信息
    /// </summary>
    private void UpdateImageSelectionStatus(string message)
    {
        imageSelectionStatus = message;
        Debug.Log("图片选择状态: " + message);
    }
#endif



    System.Collections.IEnumerator ShowLoadDialogCoroutine()
    {
        yield return FileBrowser.WaitForLoadDialog(FileBrowser.PickMode.Files, false, null, null, "选择图片", "选择");

        if (FileBrowser.Success)
        {
            string path = FileBrowser.Result[0];
            selectedImagePath = path;
            lastError = "";
            LoadImagePreview(path);
        }
    }

    void LoadImagePreview(string imagePath)
    {
        try
        {
            Debug.Log($"尝试加载图片预览: {imagePath}");

            if (!File.Exists(imagePath))
            {
                Debug.LogError($"图片文件不存在: {imagePath}");
                return;
            }

            // 清除之前的纹理
            if (currentImageTexture != null)
            {
                DestroyImmediate(currentImageTexture);
                currentImageTexture = null;
            }

            // 加载图片数据
            byte[] imageData = File.ReadAllBytes(imagePath);
            Debug.Log($"加载了 {imageData.Length} 字节的图片数据");

            currentImageTexture = new Texture2D(2, 2);
            bool loadSuccess = currentImageTexture.LoadImage(imageData);

            if (loadSuccess)
            {
                Debug.Log($"成功加载纹理: {currentImageTexture.width}x{currentImageTexture.height}");
            }
            else
            {
                Debug.LogError("无法将图片数据加载到纹理中");
                DestroyImmediate(currentImageTexture);
                currentImageTexture = null;
            }
        }
        catch (Exception ex)
        {
            Debug.LogError($"加载图片预览失败: {ex.Message}");
            if (currentImageTexture != null)
            {
                DestroyImmediate(currentImageTexture);
                currentImageTexture = null;
            }
        }
    }

    // 修改后的 ClearCurrentModel 方法
    void ClearCurrentModel()
    {
        if (currentModel != null)
        {
            string filePath = "";

            // 从列表中移除并获取文件路径
            for (int i = allModels.Count - 1; i >= 0; i--)
            {
                if (allModels[i].modelObject == currentModel)
                {
                    filePath = allModels[i].filePath;
                    allModels.RemoveAt(i);
                    modelToggleStates.RemoveAt(i);
                    break;
                }
            }

            DestroyImmediate(currentModel);
            currentModel = allModels.Count > 0 ? allModels[allModels.Count - 1].modelObject : null;

            // 如果清除的模型来自文件，更新对应的文件状态
            if (!string.IsNullOrEmpty(filePath))
            {
                for (int i = 0; i < existingModelFiles.Count; i++)
                {
                    if (existingModelFiles[i] == filePath)
                    {
                        existingModelStates[i] = false;
                        break;
                    }
                }
            }

            Debug.Log("已清除当前模型");
        }
    }


    void LoadModelIntoScene(string modelPath)
    {
        StartCoroutine(LoadModelCoroutine(modelPath));
    }

    IEnumerator LoadModelCoroutine(string modelPath)
    {
        Debug.Log($"开始加载模型: {modelPath}");

        // 清除之前的模型
        ClearCurrentModel();

        // 使用GLTFast加载GLB文件
        var gltf = new GltfImport();

        // 将异步加载转换为协程
        var loadTask = gltf.LoadFile(modelPath);
        yield return new WaitUntil(() => loadTask.IsCompleted);

        if (loadTask.Result)
        {
            // 实例化模型
            var instantiateTask = gltf.InstantiateMainSceneAsync(modelParent);
            yield return new WaitUntil(() => instantiateTask.IsCompleted);

            if (instantiateTask.Result)
            {
                // 获取生成的模型对象
                currentModel = modelParent.GetChild(modelParent.childCount - 1).gameObject;

                // 设置模型位置和缩放
                currentModel.transform.localPosition = Vector3.zero;
                currentModel.transform.localScale = modelScale;
                currentModel.transform.rotation = Quaternion.identity; // 重置旋转

                // 计算模型边界并调整位置
                Renderer[] renderers = currentModel.GetComponentsInChildren<Renderer>();
                if (renderers.Length > 0)
                {
                    Bounds bounds = renderers[0].bounds;
                    foreach (var renderer in renderers)
                    {
                        bounds.Encapsulate(renderer.bounds);
                    }

                    // 将模型中心移到原点
                    Vector3 centerOffset = bounds.center - modelParent.position;
                    currentModel.transform.position -= centerOffset;
                }

                // 添加到模型列表
                string modelName = $"Model_{allModels.Count + 1}_{DateTime.Now:HHmmss}";
                currentModel.name = modelName;

                ModelInfo newModel = new ModelInfo
                {
                    modelObject = currentModel,
                    modelName = modelName,
                    filePath = modelPath
                };

                allModels.Add(newModel);
                modelToggleStates.Add(true); // 新模型默认显示

                // 隐藏其他所有模型，只显示最新的
                for (int i = 0; i < allModels.Count - 1; i++)
                {
                    if (allModels[i].modelObject != null)
                    {
                        allModels[i].modelObject.SetActive(false);
                        modelToggleStates[i] = false;
                    }
                }

                Debug.Log($"模型加载成功: {currentModel.name}");

                // 在Unity编辑器中刷新
#if UNITY_EDITOR
                UnityEditor.SceneView.RepaintAll();
#endif
            }
            else
            {
                Debug.LogError("模型实例化失败");
            }
        }
        else
        {
            Debug.LogError("GLB文件加载失败");
        }
    }


    IEnumerator CheckServerConnection()
    {
        connectionStatus = "连接中...";
        isConnected = false;

        using (UnityWebRequest request = UnityWebRequest.Get($"{serverUrl}/"))
        {
            request.timeout = 10;
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                try
                {
                    serverInfo = JsonConvert.DeserializeObject<ServerInfo>(request.downloadHandler.text);
                    isConnected = true;
                    connectionStatus = "已连接";
                    lastError = "";
                }
                catch (Exception e)
                {
                    isConnected = false;
                    connectionStatus = "连接失败";
                    lastError = $"解析服务器信息失败: {e.Message}";
                }
            }
            else
            {
                isConnected = false;
                connectionStatus = "连接失败";
                lastError = $"连接错误: {request.error}";
            }
        }
    }

    IEnumerator GenerateModel()
    {
        if (string.IsNullOrEmpty(selectedImagePath) || !File.Exists(selectedImagePath))
        {
            lastError = "请选择有效的图片文件";
            yield break;
        }

        // 确保下载文件夹存在
        EnsureDownloadFolderExists();

        isGenerating = true;
        progress = 0f;
        progressMessage = "准备上传图片...";
        lastError = "";
        lastResult = null;

        // 读取图片文件
        byte[] imageData;
        try
        {
            imageData = File.ReadAllBytes(selectedImagePath);
            progressMessage = "上传图片并生成模型...";
            progress = 0.1f;
        }
        catch (Exception e)
        {
            lastError = $"读取图片文件失败: {e.Message}";
            isGenerating = false;
            yield break;
        }

        // 创建表单数据
        List<IMultipartFormSection> formData = new List<IMultipartFormSection>();
        formData.Add(new MultipartFormFileSection("file", imageData, Path.GetFileName(selectedImagePath), "image/png"));
        formData.Add(new MultipartFormDataSection("steps", steps.ToString()));
        formData.Add(new MultipartFormDataSection("guidance_scale", guidanceScale.ToString()));
        formData.Add(new MultipartFormDataSection("seed", seed.ToString()));
        formData.Add(new MultipartFormDataSection("octree_resolution", octreeResolution.ToString()));
        formData.Add(new MultipartFormDataSection("remove_bg", removeBackground.ToString().ToLower()));
        formData.Add(new MultipartFormDataSection("randomize_seed", randomizeSeed.ToString().ToLower()));
        formData.Add(new MultipartFormDataSection("include_texture", includeTexture.ToString().ToLower()));
        formData.Add(new MultipartFormDataSection("file_type", fileType));
        formData.Add(new MultipartFormDataSection("num_chunks", numChunks.ToString()));

        // 发送生成请求
        using (UnityWebRequest request = UnityWebRequest.Post($"{serverUrl}/generate_sync", formData))
        {
            request.timeout = 300; // 5分钟超时

            var operation = request.SendWebRequest();

            // 模拟进度更新
            float startTime = Time.time;
            while (!operation.isDone)
            {
                float elapsed = Time.time - startTime;
                progress = Mathf.Clamp01(0.1f + (elapsed / 120f) * 0.8f); // 假设2分钟完成
                progressMessage = $"正在生成模型... ({elapsed:F0}秒)";
                yield return null;
            }

            progress = 0.9f;
            progressMessage = "处理服务器响应...";

            if (request.result == UnityWebRequest.Result.Success)
            {
                try
                {
                    var response = JsonConvert.DeserializeObject<GenerationResponse>(request.downloadHandler.text);

                    if (response.success)
                    {
                        lastResult = new GenerationResult
                        {
                            seed = response.seed,
                            stats = response.stats,
                            files = response.files
                        };

                        progress = 1f;
                        progressMessage = "生成完成！";

                        // 自动下载文件
                        if (response.files != null)
                        {
                            foreach (var file in response.files)
                            {
                                StartCoroutine(DownloadFileAndLoad(file.Value.download_url, file.Value.filename, file.Key));
                            }
                        }
                    }
                    else
                    {
                        lastError = $"生成失败: {response.message}";
                    }
                }
                catch (Exception e)
                {
                    lastError = $"解析响应失败: {e.Message}";
                }
            }
            else
            {
                lastError = $"请求失败: {request.error}";
            }
        }

        isGenerating = false;
    }

    // 修改 DownloadFile 协程方法
    IEnumerator DownloadFile(string url, string originalFilename)
    {
        progressMessage = $"下载文件: {originalFilename}...";
        progress = 0.8f;

        // 检查URL格式
        string fullUrl;
        if (url.StartsWith("http://") || url.StartsWith("https://"))
        {
            fullUrl = url;
        }
        else
        {
            if (!url.StartsWith("/"))
            {
                url = "/" + url;
            }
            fullUrl = $"{serverUrl}{url}";
        }

        Debug.Log($"下载URL: {fullUrl}");

        using (UnityWebRequest request = UnityWebRequest.Get(fullUrl))
        {
            request.timeout = 300; // 5分钟超时
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                try
                {
                    // 生成唯一的文件名
                    string uniqueFilename = GenerateUniqueFilename(originalFilename);
                    string filePath = Path.Combine(currentDownloadFolder, uniqueFilename);

                    File.WriteAllBytes(filePath, request.downloadHandler.data);
                    Debug.Log($"文件下载成功: {filePath}");

                    progressMessage = $"下载完成: {uniqueFilename}";
                    progress = 0.9f;

                    // 刷新本地文件列表
                    ScanExistingModelFiles();

                    // 如果是GLB文件，自动加载到场景中
                    if (Path.GetExtension(uniqueFilename).ToLower() == ".glb")
                    {
                        progressMessage = "加载模型到场景...";
                        LoadModelIntoScene(filePath);
                    }
                }
                catch (Exception e)
                {
                    lastError = $"保存文件失败: {e.Message}";
                    Debug.LogError(lastError);
                }
            }
            else
            {
                lastError = $"下载失败: {request.error}";
                Debug.LogError(lastError);
            }
        }
    }


    // 新增方法：生成唯一文件名
    private string GenerateUniqueFilename(string originalFilename)
    {
        // 增加模型计数器
        modelCounter++;

        // 获取当前时间戳
        string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");

        // 分离文件名和扩展名
        string nameWithoutExtension = Path.GetFileNameWithoutExtension(originalFilename);
        string extension = Path.GetExtension(originalFilename);

        // 生成新的文件名：原名_序号_时间戳.扩展名
        string uniqueFilename = $"{nameWithoutExtension}_{modelCounter:D3}_{timestamp}{extension}";

        // 确保文件名不重复（万一时间戳相同）
        string fullPath = Path.Combine(currentDownloadFolder, uniqueFilename);
        int duplicateCounter = 1;
        while (File.Exists(fullPath))
        {
            uniqueFilename = $"{nameWithoutExtension}_{modelCounter:D3}_{timestamp}_{duplicateCounter:D2}{extension}";
            fullPath = Path.Combine(currentDownloadFolder, uniqueFilename);
            duplicateCounter++;
        }

        return uniqueFilename;
    }

    IEnumerator DownloadFileAndLoad(string downloadUrl, string filename, string fileType)
    {
        string fullUrl;

        // 检查downloadUrl是否已经是完整URL
        if (downloadUrl.StartsWith("http://") || downloadUrl.StartsWith("https://"))
        {
            fullUrl = downloadUrl;
        }
        else
        {
            // 确保downloadUrl以/开头
            if (!downloadUrl.StartsWith("/"))
            {
                downloadUrl = "/" + downloadUrl;
            }
            fullUrl = $"{serverUrl}{downloadUrl}";
        }

        string uniqueFilename = GenerateUniqueFilename(filename);
        string localPath = Path.Combine(currentDownloadFolder, uniqueFilename);

        Debug.Log($"开始下载: {fullUrl} -> {localPath}");

        using (UnityWebRequest request = UnityWebRequest.Get(fullUrl))
        {
            request.timeout = 300; // 增加超时时间到5分钟
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                try
                {
                    File.WriteAllBytes(localPath, request.downloadHandler.data);
                    Debug.Log($"文件下载成功: {localPath}");

                    // 刷新本地文件列表
                    ScanExistingModelFiles();

#if UNITY_EDITOR
                    UnityEditor.AssetDatabase.Refresh();
#endif

                    // 如果是带纹理的模型，自动加载到场景中
                    if (fileType == "textured_mesh" && uniqueFilename.EndsWith(".glb"))
                    {
                        yield return new WaitForSeconds(0.5f); // 等待文件写入完成
                        LoadModelIntoScene(localPath);
                    }
                }
                finally { }
            }
            else
            {
                Debug.LogError($"下载失败: {request.error}");
                lastError = $"下载失败: {request.error}";
            }
        }
    }


    void OnDestroy()
    {
        // 清理资源
        if (currentImageTexture != null)
        {
            DestroyImmediate(currentImageTexture);
        }

        // 清理图片缓存
        ClearImageCache();

        // 清理所有模型
        ClearAllModels();
    }


}

// 数据类定义
[System.Serializable]
public class ServerInfo
{
    public string version;
    public ServerFeatures features;
}

[System.Serializable]
public class ServerFeatures
{
    public bool texture_generation;
    public bool text_to_image;
}

[System.Serializable]
public class GenerationResponse
{
    public bool success;
    public string message;
    public int seed;
    public GenerationStats stats;
    public Dictionary<string, FileInfo> files;
}

[System.Serializable]
public class GenerationResult
{
    public int seed;
    public GenerationStats stats;
    public Dictionary<string, FileInfo> files;
}

[System.Serializable]
public class GenerationStats
{
    public TimeStats time;
    public int number_of_faces;
    public int number_of_vertices;
}

[System.Serializable]
public class TimeStats
{
    public float total;
    public float preprocessing;
    public float generation;
    public float postprocessing;
}

[System.Serializable]
public class FileInfo
{
    public string filename;
    public string download_url;
    public long size;
}
