#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hunyuan3D Flask API服务器
基于gradio_app.py的核心功能，提供REST API接口供Unity调用
支持完整的3D模型生成和材质纹理生成
"""

import sys
sys.path.insert(0, './hy3dshape')
sys.path.insert(0, './hy3dpaint')

# Apply torchvision compatibility fix
try:
  from torchvision_fix import apply_fix
  apply_fix()
except ImportError:
  print("Warning: torchvision_fix module not found, proceeding without compatibility fix")
except Exception as e:
  print(f"Warning: Failed to apply torchvision fix: {e}")

import os
import random
import shutil
import time
import uuid
import threading
import argparse
from datetime import datetime
from pathlib import Path
from glob import glob

import torch
import trimesh
import numpy as np
from flask import Flask, request, jsonify, send_from_directory, send_file
from werkzeug.utils import secure_filename
from PIL import Image

# Hunyuan3D imports
from hy3dshape.utils import logger
from hy3dshape import (
  FaceReducer, FloaterRemover, DegenerateFaceRemover,
  Hunyuan3DDiTFlowMatchingPipeline
)
from hy3dshape.pipelines import export_to_trimesh
from hy3dshape.rembg import BackgroundRemover
from hy3dpaint.convert_utils import create_glb_with_pbr_materials

app = Flask(__name__)

# 配置
UPLOAD_FOLDER = 'uploaded_images'
OUTPUT_FOLDER = 'generated_models'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'tiff', 'webp'}
MAX_CONTENT_LENGTH = 32 * 1024 * 1024  # 32MB
MAX_SEED = 1e7
SUPPORTED_FORMATS = ['glb', 'obj', 'ply', 'stl']

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['OUTPUT_FOLDER'] = OUTPUT_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH

# 全局变量
generation_tasks = {}  # 存储生成任务的状态
server_running = False

# 模型工作器
i23d_worker = None
rmbg_worker = None
face_reduce_worker = None
floater_remove_worker = None
degenerate_face_remove_worker = None
tex_pipeline = None
t2i_worker = None

# 默认参数（从gradio_app.py移植）
DEFAULT_ARGS = argparse.Namespace(
  model_path='tencent/Hunyuan3D-2.1',
  subfolder='hunyuan3d-dit-v2-1',
  texgen_model_path='tencent/Hunyuan3D-2.1',
  low_vram_mode=False,
  enable_t23d=False,
  disable_tex=False,
  mv_mode=False,
  turbo_mode=False,
  device='cuda' if torch.cuda.is_available() else 'cpu',
  mc_algo='mc',
  enable_flashvdm=False,
  compile=False
)

def log_message(message):
  """统一的日志输出"""
  timestamp = datetime.now().strftime('%H:%M:%S')
  print(f"[{timestamp}] {message}")
  logger.info(message)

def ensure_folders():
  """确保必要的文件夹存在"""
  for folder in [UPLOAD_FOLDER, OUTPUT_FOLDER]:
      if not os.path.exists(folder):
          os.makedirs(folder)
          log_message(f"📁 创建文件夹: {folder}")

def allowed_file(filename):
  """检查文件扩展名是否允许"""
  return '.' in filename and \
         filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def randomize_seed_fn(seed: int, randomize_seed: bool) -> int:
  """随机化种子函数"""
  if randomize_seed:
      seed = random.randint(0, int(MAX_SEED))
  return seed

def gen_save_folder(max_size=200):
  """生成保存文件夹"""
  os.makedirs(OUTPUT_FOLDER, exist_ok=True)
  dirs = [f for f in Path(OUTPUT_FOLDER).iterdir() if f.is_dir()]
  if len(dirs) >= max_size:
      oldest_dir = min(dirs, key=lambda x: x.stat().st_ctime)
      shutil.rmtree(oldest_dir)
      log_message(f"🗑️ 删除最旧文件夹: {oldest_dir}")
  
  new_folder = os.path.join(OUTPUT_FOLDER, str(uuid.uuid4()))
  os.makedirs(new_folder, exist_ok=True)
  return new_folder

def export_mesh(mesh, save_folder, textured=False, file_type='glb'):
  """导出网格文件"""
  if textured:
      path = os.path.join(save_folder, f'textured_mesh.{file_type}')
  else:
      path = os.path.join(save_folder, f'white_mesh.{file_type}')
  
  try:
      if file_type not in ['glb', 'obj']:
          mesh.export(path)
      else:
          mesh.export(path, include_normals=textured)
      return path
  except Exception as e:
      log_message(f"❌ 导出网格失败: {e}")
      raise

def quick_convert_with_obj2gltf(obj_path: str, glb_path: str) -> bool:
  """快速转换OBJ到GLB格式"""
  try:
      textures = {
          'albedo': obj_path.replace('.obj', '.jpg'),
          'metallic': obj_path.replace('.obj', '_metallic.jpg'),
          'roughness': obj_path.replace('.obj', '_roughness.jpg')
      }
      create_glb_with_pbr_materials(obj_path, textures, glb_path)
      return True
  except Exception as e:
      log_message(f"❌ OBJ到GLB转换失败: {e}")
      return False

def init_hunyuan_models():
  """初始化Hunyuan3D模型"""
  global i23d_worker, rmbg_worker, face_reduce_worker
  global floater_remove_worker, degenerate_face_remove_worker, tex_pipeline, t2i_worker
  
  try:
      log_message("🔄 正在初始化Hunyuan3D模型...")
      
      # 初始化背景移除工具
      log_message("📸 加载背景移除模型...")
      rmbg_worker = BackgroundRemover()
      
      # 初始化主要的3D生成模型
      log_message("🎯 加载3D生成模型...")
      i23d_worker = Hunyuan3DDiTFlowMatchingPipeline.from_pretrained(
          DEFAULT_ARGS.model_path,
          subfolder=DEFAULT_ARGS.subfolder,
          use_safetensors=False,
          device=DEFAULT_ARGS.device,
      )
      
      # 启用FlashVDM（如果需要）
      if DEFAULT_ARGS.enable_flashvdm:
          mc_algo = 'mc' if DEFAULT_ARGS.device in ['cpu', 'mps'] else DEFAULT_ARGS.mc_algo
          i23d_worker.enable_flashvdm(mc_algo=mc_algo)
      
      # 编译模型（如果需要）
      if DEFAULT_ARGS.compile:
          i23d_worker.compile()
      
      # 初始化后处理工具
      log_message("🔧 加载后处理工具...")
      floater_remove_worker = FloaterRemover()
      degenerate_face_remove_worker = DegenerateFaceRemover()
      face_reduce_worker = FaceReducer()
      
      # 初始化纹理生成管道（如果可用且未禁用）
      if not DEFAULT_ARGS.disable_tex:
          try:
              log_message("🎨 加载纹理生成模型...")
              
              # 应用torchvision兼容性修复
              try:
                  from torchvision_fix import apply_fix
                  fix_result = apply_fix()
                  if not fix_result:
                      log_message("⚠️ Torchvision修复可能未成功应用")
              except Exception as fix_error:
                  log_message(f"⚠️ 应用torchvision修复失败: {fix_error}")
              
              # 导入纹理生成管道
              from hy3dpaint.textureGenPipeline import Hunyuan3DPaintPipeline, Hunyuan3DPaintConfig
              
              # 配置纹理生成
              conf = Hunyuan3DPaintConfig(max_num_view=8, resolution=768)
              conf.realesrgan_ckpt_path = "hy3dpaint/ckpt/RealESRGAN_x4plus.pth"
              conf.multiview_cfg_path = "hy3dpaint/cfgs/hunyuan-paint-pbr.yaml"
              conf.custom_pipeline = "hy3dpaint/hunyuanpaintpbr"
              
              tex_pipeline = Hunyuan3DPaintPipeline(conf)
              
              # 低显存模式
              if DEFAULT_ARGS.low_vram_mode:
                  # tex_pipeline.enable_model_cpu_offload()  # 如果支持的话
                  pass
              
              log_message("✅ 纹理生成模型加载成功")
              
          except Exception as e:
              import traceback
              traceback.print_exc()
              log_message(f"⚠️ 纹理生成模型加载失败: {e}")
              tex_pipeline = None
      else:
          log_message("⚠️ 纹理生成已禁用")
          tex_pipeline = None
      
      # 初始化文本到图像模型（如果启用）
      if DEFAULT_ARGS.enable_t23d:
          try:
              log_message("📝 加载文本到图像模型...")
              from hy3dgen.text2image import HunyuanDiTPipeline
              t2i_worker = HunyuanDiTPipeline('Tencent-Hunyuan/HunyuanDiT-v1.1-Diffusers-Distilled')
              log_message("✅ 文本到图像模型加载成功")
          except Exception as e:
              log_message(f"⚠️ 文本到图像模型加载失败: {e}")
              t2i_worker = None
      
      log_message("✅ Hunyuan3D模型初始化完成")
      return True
      
  except Exception as e:
      import traceback
      traceback.print_exc()
      log_message(f"❌ 模型初始化失败: {e}")
      return False

def _gen_shape_core(
  image=None,
  caption=None,
  mv_image_front=None,
  mv_image_back=None,
  mv_image_left=None,
  mv_image_right=None,
  steps=50,
  guidance_scale=7.5,
  seed=1234,
  octree_resolution=256,
  check_box_rembg=True,
  num_chunks=200000,
  randomize_seed=False,
):
  """核心3D生成函数（从gradio_app.py移植）"""
  try:
      # 检查输入
      if not DEFAULT_ARGS.mv_mode and image is None and caption is None:
          raise ValueError("请提供图片或文本描述")
      
      if DEFAULT_ARGS.mv_mode:
          if mv_image_front is None and mv_image_back is None and \
             mv_image_left is None and mv_image_right is None:
              raise ValueError("请至少提供一个视角的图片")
          image = {}
          if mv_image_front:
              image['front'] = mv_image_front
          if mv_image_back:
              image['back'] = mv_image_back
          if mv_image_left:
              image['left'] = mv_image_left
          if mv_image_right:
              image['right'] = mv_image_right
      
      # 随机化种子
      seed = int(randomize_seed_fn(seed, randomize_seed))
      octree_resolution = int(octree_resolution)
      
      if caption:
          log_message(f"📝 文本提示: {caption}")
      
      # 创建保存文件夹
      save_folder = gen_save_folder()

            # 在这里添加：保存原始输入图片
      original_image = image  # 保存原始图片引用
      
      # 统计信息
      stats = {
          'model': {
              'shapegen': f'{DEFAULT_ARGS.model_path}/{DEFAULT_ARGS.subfolder}',
              'texgen': f'{DEFAULT_ARGS.texgen_model_path}',
          },
          'params': {
              'caption': caption,
              'steps': steps,
              'guidance_scale': guidance_scale,
              'seed': seed,
              'octree_resolution': octree_resolution,
              'check_box_rembg': check_box_rembg,
              'num_chunks': num_chunks,
          }
      }
      time_meta = {}
      
      # 文本到图像（如果需要）
      if image is None and caption is not None:
          if t2i_worker is None:
              raise ValueError("文本到3D功能未启用，请提供图片")
          
          start_time = time.time()
          try:
              image = t2i_worker(caption)
              time_meta['text2image'] = time.time() - start_time
              log_message(f"📝 文本到图像完成，耗时: {time_meta['text2image']:.2f}秒")
          except Exception as e:
              raise ValueError(f"文本到图像生成失败: {e}")
      
      # 背景移除
      if DEFAULT_ARGS.mv_mode:
          if check_box_rembg:
              start_time = time.time()
              for k, v in image.items():
                  if v.mode == "RGB":
                      img = rmbg_worker(v.convert('RGB'))
                      image[k] = img
              time_meta['remove_background'] = time.time() - start_time
              log_message(f"🎭 多视角背景移除完成，耗时: {time_meta['remove_background']:.2f}秒")
      else:
          if check_box_rembg or image.mode == "RGB":
              start_time = time.time()
              image = rmbg_worker(image.convert('RGB'))
              time_meta['remove_background'] = time.time() - start_time
              log_message(f"🎭 背景移除完成，耗时: {time_meta['remove_background']:.2f}秒")
      
      # 3D形状生成
      start_time = time.time()
      generator = torch.Generator()
      generator = generator.manual_seed(int(seed))
      
      outputs = i23d_worker(
          image=image,
          num_inference_steps=steps,
          guidance_scale=guidance_scale,
          generator=generator,
          octree_resolution=octree_resolution,
          num_chunks=num_chunks,
          output_type='mesh'
      )
      time_meta['shape_generation'] = time.time() - start_time
      log_message(f"🏗️ 形状生成完成，耗时: {time_meta['shape_generation']:.2f}秒")
      
      # 导出为trimesh
      tmp_start = time.time()
      mesh = export_to_trimesh(outputs)[0]
      time_meta['export_to_trimesh'] = time.time() - tmp_start
      
      # 更新统计信息
      stats['number_of_faces'] = mesh.faces.shape[0]
      stats['number_of_vertices'] = mesh.vertices.shape[0]
      stats['time'] = time_meta
      
# 在函数最后，保存图片到模型文件夹
      if original_image is not None:
          try:
              if DEFAULT_ARGS.mv_mode and isinstance(original_image, dict):
                  # 多视角模式：保存所有视角图片
                  for view_name, img in original_image.items():
                      if img is not None:
                          img_path = os.path.join(save_folder, f'input_image_{view_name}.png')
                          img.save(img_path, 'PNG')
                          log_message(f"💾 保存输入图片 ({view_name}): {img_path}")
              else:
                  # 单图片模式：保存主图片
                  img_path = os.path.join(save_folder, 'input_image.png')
                  original_image.save(img_path, 'PNG')
                  log_message(f"💾 保存输入图片: {img_path}")
          except Exception as e:
              log_message(f"⚠️ 保存输入图片失败: {e}")
      
      main_image = image if not DEFAULT_ARGS.mv_mode else image['front']
      return mesh, main_image, save_folder, stats, seed
      
  except Exception as e:
      log_message(f"❌ 3D生成核心函数失败: {e}")
      raise

def generate_3d_model_complete(
  image_path=None,
  caption=None,
  mv_image_paths=None,
  original_filename=None,  # 新增参数
  steps=50,
  guidance_scale=7.5,
  seed=1234,
  octree_resolution=256,
  check_box_rembg=True,
  num_chunks=200000,
  randomize_seed=False,
  include_texture=False,
  file_type='glb'
):
  """完整的3D模型生成流程"""
  try:
      start_time_total = time.time()
      log_message(f"🚀 开始完整3D生成流程")
      
      # 准备图片输入
      image = None
      mv_images = {}
      
      if image_path and os.path.exists(image_path):
          image = Image.open(image_path).convert('RGBA')
          log_message(f"📷 图片加载完成: {image.size}")
      
      if mv_image_paths:
          for view, path in mv_image_paths.items():
              if path and os.path.exists(path):
                  mv_images[view] = Image.open(path).convert('RGBA')
                  log_message(f"📷 {view}视角图片加载完成")
      
      # 核心生成
      mesh, processed_image, save_folder, stats, final_seed = _gen_shape_core(
          image=image,
          caption=caption,
          mv_image_front=mv_images.get('front'),
          mv_image_back=mv_images.get('back'),
          mv_image_left=mv_images.get('left'),
          mv_image_right=mv_images.get('right'),
          steps=steps,
          guidance_scale=guidance_scale,
          seed=seed,
          octree_resolution=octree_resolution,
          check_box_rembg=check_box_rembg,
          num_chunks=num_chunks,
          randomize_seed=randomize_seed,
      )
      
      # 后处理
      log_message("🔧 开始后处理...")
      tmp_time = time.time()
      
      # 移除浮动点和退化面（可选，可能会导致core dump）
      # mesh = floater_remove_worker(mesh)
      # mesh = degenerate_face_remove_worker(mesh)
      
      # 面数简化
      mesh = face_reduce_worker(mesh)
      stats['time']['face_reduction'] = time.time() - tmp_time
      log_message(f"✂️ 面数简化完成，耗时: {stats['time']['face_reduction']:.2f}秒")
      
      # 导出基础网格
      if file_type == 'glb':
          # 先导出为OBJ，再转换为GLB
          obj_path = export_mesh(mesh, save_folder, textured=False, file_type='obj')
          white_mesh_path = os.path.join(save_folder, f'white_mesh.{file_type}')
          # 简单的GLB转换（不包含纹理）
          mesh.export(white_mesh_path, include_normals=False)
      else:
          white_mesh_path = export_mesh(mesh, save_folder, textured=False, file_type=file_type)
      
      textured_mesh_path = None
      if include_texture and tex_pipeline is not None:
          try:
              tmp_time = time.time()
              log_message("🎨 开始纹理生成...")
              
              # 导出OBJ用于纹理生成
              obj_path = export_mesh(mesh, save_folder, textured=False, file_type='obj')
              textured_obj_path = os.path.join(save_folder, 'textured_mesh.obj')
              
              # 生成纹理
              path_textured = tex_pipeline(
                  mesh_path=obj_path,
                  image_path=processed_image,
                  output_mesh_path=textured_obj_path,
                  save_glb=False
              )
              
              stats['time']['texture_generation'] = time.time() - tmp_time
              log_message(f"🎨 纹理生成完成，耗时: {stats['time']['texture_generation']:.2f}秒")
              
              # 转换为GLB（如果需要）
              if file_type == 'glb':
                  tmp_time = time.time()
                  textured_mesh_path = os.path.join(save_folder, 'textured_mesh.glb')
                  conversion_success = quick_convert_with_obj2gltf(path_textured, textured_mesh_path)
                  
                  if conversion_success:
                      stats['time']['convert_textured_obj_to_glb'] = time.time() - tmp_time
                      log_message(f"🔄 纹理GLB转换完成，耗时: {stats['time']['convert_textured_obj_to_glb']:.2f}秒")
                  else:
                      textured_mesh_path = path_textured  # 回退到OBJ
              else:
                  textured_mesh_path = path_textured
              
          except Exception as e:
              log_message(f"⚠️ 纹理生成失败: {e}")
              textured_mesh_path = None
      
      # 更新总时间
      stats['time']['total'] = time.time() - start_time_total
      
      # 清理GPU内存
      if DEFAULT_ARGS.low_vram_mode and torch.cuda.is_available():
          torch.cuda.empty_cache()
      
      log_message(f"✅ 完整生成流程完成，总耗时: {stats['time']['total']:.2f}秒")
      
      return {
          'success': True,
          'save_folder': save_folder,
          'white_mesh': white_mesh_path,
          'textured_mesh': textured_mesh_path,
          'stats': stats,
          'seed': final_seed
      }

              # 在这里添加：保存原始上传的图片到模型文件夹
      if image_path and os.path.exists(image_path) and original_filename:
            try:
                # 确定保存的文件名和扩展名
                original_ext = os.path.splitext(original_filename)[1].lower()
                if not original_ext:
                    original_ext = '.png'
                
                saved_image_path = os.path.join(save_folder, f'original_input{original_ext}')
                
                # 复制原始文件到模型文件夹
                shutil.copy2(image_path, saved_image_path)
                log_message(f"💾 保存原始输入图片: {saved_image_path}")
                
            except Exception as e:
                log_message(f"⚠️ 保存原始输入图片失败: {e}")
      
  except Exception as e:
      import traceback
      traceback.print_exc()
      log_message(f"❌ 完整生成流程失败: {e}")
      return {
          'success': False,
          'error': str(e)
      }

# API路由
@app.route('/')
def index():
  """主页"""
  return jsonify({
      'message': 'Hunyuan3D Flask API Server',
      'status': 'running',
      'version': '2.1',
      'features': {
          'shape_generation': True,
          'texture_generation': tex_pipeline is not None,
          'text_to_image': t2i_worker is not None,
          'multiview_mode': DEFAULT_ARGS.mv_mode,
          'background_removal': True
      },
      'endpoints': {
          'upload': '/upload - 上传图片文件',
          'generate': '/generate - 异步生成3D模型',
          'generate_sync': '/generate_sync - 同步生成3D模型',
          'generate_text': '/generate_text - 文本生成3D模型',
          'status': '/status/<task_id> - 查询任务状态',
          'download': '/download/<path:filename> - 下载文件',
          'health': '/health - 健康检查',
          'cleanup': '/cleanup - 清理旧文件'
      },
      'supported_formats': SUPPORTED_FORMATS,
      'max_file_size': '32MB'
  })

@app.route('/health')
def health_check():
  """健康检查"""
  gpu_info = {}
  if torch.cuda.is_available():
      gpu_info = {
          'device_name': torch.cuda.get_device_name(0),
          'total_memory': torch.cuda.get_device_properties(0).total_memory,
          'allocated_memory': torch.cuda.memory_allocated(0),
          'cached_memory': torch.cuda.memory_reserved(0)
      }
  
  return jsonify({
      'status': 'healthy',
      'timestamp': datetime.now().isoformat(),
      'server_running': server_running,
      'models_loaded': {
          'shape_generator': i23d_worker is not None,
          'texture_generator': tex_pipeline is not None,
          'text_to_image': t2i_worker is not None,
          'background_remover': rmbg_worker is not None
      },
      'gpu_available': torch.cuda.is_available(),
      'gpu_info': gpu_info,
      'active_tasks': len(generation_tasks)
  })

@app.route('/upload', methods=['POST'])
def upload_file():
  """上传图片文件"""
  try:
      if 'file' not in request.files:
          return jsonify({'error': '没有文件被上传'}), 400
      
      file = request.files['file']
      if file.filename == '':
          return jsonify({'error': '没有选择文件'}), 400
      
      if file and allowed_file(file.filename):
          filename = secure_filename(file.filename)
          # 添加时间戳避免文件名冲突
          timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
          name, ext = os.path.splitext(filename)
          filename = f"{name}_{timestamp}{ext}"
          
          filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
          file.save(filepath)
          
          # 验证图片
          try:
              with Image.open(filepath) as img:
                  img.verify()
              log_message(f"📤 文件上传成功: {filename}")
          except Exception as e:
              os.remove(filepath)
              return jsonify({'error': f'无效的图片文件: {str(e)}'}), 400
          
          return jsonify({
              'success': True,
              'filename': filename,
              'filepath': filepath,
              'message': '文件上传成功'
          })
      else:
          return jsonify({'error': '不支持的文件类型'}), 400
          
  except Exception as e:
      log_message(f"❌ 文件上传失败: {e}")
      return jsonify({'error': f'上传失败: {str(e)}'}), 500

@app.route('/generate_sync', methods=['POST'])
def generate_model_sync():
  """同步生成3D模型 - Unity推荐使用此接口"""
  try:
      # 检查是否有文件上传
      if 'file' not in request.files:
          return jsonify({'error': '没有文件被上传'}), 400
      
      file = request.files['file']
      if not file or not allowed_file(file.filename):
          return jsonify({'error': '无效的文件'}), 400
      
      # 保存临时文件
      temp_filename = f"temp_{uuid.uuid4()}.png"
      temp_path = os.path.join(UPLOAD_FOLDER, temp_filename)
      file.save(temp_path)
      
      try:
          # 获取参数
          steps = int(request.form.get('steps', 30))
          guidance_scale = float(request.form.get('guidance_scale', 7.5))
          seed = int(request.form.get('seed', 1234))
          octree_resolution = int(request.form.get('octree_resolution', 256))
          check_box_rembg = request.form.get('remove_bg', 'true').lower() == 'true'
          randomize_seed = request.form.get('randomize_seed', 'false').lower() == 'true'
          include_texture = request.form.get('include_texture', 'false').lower() == 'true'
          file_type = request.form.get('file_type', 'glb')
          num_chunks = int(request.form.get('num_chunks', 200000))
          
          # 验证参数
          if file_type not in SUPPORTED_FORMATS:
              file_type = 'glb'
          
          log_message(f"🎯 开始同步生成 - 参数: steps={steps}, seed={seed}, texture={include_texture}")
          
          # 直接生成（同步）
          result = generate_3d_model_complete(
              image_path=temp_path,
              original_filename=file.filename,  # 添加这个参数
              steps=steps,
              guidance_scale=guidance_scale,
              seed=seed,
              octree_resolution=octree_resolution,
              check_box_rembg=check_box_rembg,
              num_chunks=num_chunks,
              randomize_seed=randomize_seed,
              include_texture=include_texture,
              file_type=file_type
          )
          
          if result['success']:
              # 准备响应数据
              response_data = {
                  'success': True,
                  'message': '3D模型生成成功',
                  'seed': result['seed'],
                  'stats': result['stats'],
                  'files': {}
              }
              
              # 添加文件下载链接
              if result['white_mesh']:
                  rel_path = os.path.relpath(result['white_mesh'], '.')
                  response_data['files']['white_mesh'] = {
                      'path': result['white_mesh'],
                      'download_url': f"/download/{rel_path}",
                      'filename': os.path.basename(result['white_mesh'])
                  }
              
              if result['textured_mesh']:
                  rel_path = os.path.relpath(result['textured_mesh'], '.')
                  response_data['files']['textured_mesh'] = {
                      'path': result['textured_mesh'],
                      'download_url': f"/download/{rel_path}",
                      'filename': os.path.basename(result['textured_mesh'])
                  }
              
              return jsonify(response_data)
          else:
              return jsonify({'error': result['error']}), 500
              
      finally:
          # 清理临时文件
          if os.path.exists(temp_path):
              os.remove(temp_path)
              
  except Exception as e:
      log_message(f"❌ 同步生成失败: {e}")
      return jsonify({'error': str(e)}), 500

@app.route('/generate', methods=['POST'])
def generate_model_async():
    """异步生成3D模型"""
    try:
        data = request.get_json()
        if not data or 'filename' not in data:
            return jsonify({'error': '缺少必要参数: filename'}), 400
        
        filename = data['filename']
        steps = data.get('steps', 30)
        guidance_scale = data.get('guidance_scale', 7.5)
        seed = data.get('seed', 1234)
        randomize_seed = data.get('randomize_seed', False)
        include_texture = data.get('include_texture', False)
        file_type = data.get('file_type', 'glb')
        
        # 检查文件是否存在
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        if not os.path.exists(filepath):
            return jsonify({'error': '文件不存在'}), 404
        
        # 创建任务ID
        task_id = str(uuid.uuid4())
        
        # 初始化任务状态
        generation_tasks[task_id] = {
            'status': 'pending',
            'progress': 0,
            'message': '任务已创建',
            'created_at': datetime.now().isoformat(),
            'filename': filename,
            'parameters': {
                'steps': steps,
                'guidance_scale': guidance_scale,
                'seed': seed,
                'randomize_seed': randomize_seed,
                'include_texture': include_texture,
                'file_type': file_type
            },
            'result': None,
            'error': None
        }
        
        # 启动异步任务
        def async_generation():
            try:
                generation_tasks[task_id]['status'] = 'running'
                generation_tasks[task_id]['message'] = '正在生成3D模型...'
                generation_tasks[task_id]['progress'] = 10
                
                result = generate_3d_model_complete(
                    image_path=filepath,
                    steps=steps,
                    guidance_scale=guidance_scale,
                    seed=seed,
                    randomize_seed=randomize_seed,
                    include_texture=include_texture,
                    file_type=file_type
                )
                
                if result['success']:
                    generation_tasks[task_id]['status'] = 'completed'
                    generation_tasks[task_id]['message'] = '生成完成'
                    generation_tasks[task_id]['progress'] = 100
                    generation_tasks[task_id]['result'] = result
                else:
                    generation_tasks[task_id]['status'] = 'failed'
                    generation_tasks[task_id]['message'] = f"生成失败: {result['error']}"
                    generation_tasks[task_id]['error'] = result['error']
                    
            except Exception as e:
                generation_tasks[task_id]['status'] = 'failed'
                generation_tasks[task_id]['message'] = f"生成失败: {str(e)}"
                generation_tasks[task_id]['error'] = str(e)
        
        thread = threading.Thread(target=async_generation)
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'success': True,
            'task_id': task_id,
            'message': '任务已创建，正在后台处理',
            'status_url': f'/status/{task_id}'
        })
        
    except Exception as e:
        log_message(f"❌ 异步生成任务创建失败: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/generate_text', methods=['POST'])
def generate_from_text():
    """文本生成3D模型"""
    try:
        if not DEFAULT_ARGS.enable_t23d or t2i_worker is None:
            return jsonify({'error': '文本到3D功能未启用'}), 400
        
        data = request.get_json()
        if not data or 'caption' not in data:
            return jsonify({'error': '缺少必要参数: caption'}), 400
        
        caption = data['caption']
        steps = data.get('steps', 30)
        guidance_scale = data.get('guidance_scale', 7.5)
        seed = data.get('seed', 1234)
        randomize_seed = data.get('randomize_seed', False)
        include_texture = data.get('include_texture', False)
        file_type = data.get('file_type', 'glb')
        
        log_message(f"📝 文本生成3D: {caption}")
        
        result = generate_3d_model_complete(
            caption=caption,
            steps=steps,
            guidance_scale=guidance_scale,
            seed=seed,
            randomize_seed=randomize_seed,
            include_texture=include_texture,
            file_type=file_type
        )
        
        if result['success']:
            response_data = {
                'success': True,
                'message': '文本3D模型生成成功',
                'caption': caption,
                'seed': result['seed'],
                'stats': result['stats'],
                'files': {}
            }
            
            if result['white_mesh']:
                rel_path = os.path.relpath(result['white_mesh'], '.')
                response_data['files']['white_mesh'] = {
                    'path': result['white_mesh'],
                    'download_url': f"/download/{rel_path}",
                    'filename': os.path.basename(result['white_mesh'])
                }
            
            if result['textured_mesh']:
                rel_path = os.path.relpath(result['textured_mesh'], '.')
                response_data['files']['textured_mesh'] = {
                    'path': result['textured_mesh'],
                    'download_url': f"/download/{rel_path}",
                    'filename': os.path.basename(result['textured_mesh'])
                }
            
            return jsonify(response_data)
        else:
            return jsonify({'error': result['error']}), 500
            
    except Exception as e:
        log_message(f"❌ 文本生成失败: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/status/<task_id>')
def get_task_status(task_id):
    """查询任务状态"""
    if task_id not in generation_tasks:
        return jsonify({'error': '任务不存在'}), 404
    
    task = generation_tasks[task_id]
    response = {
        'task_id': task_id,
        'status': task['status'],
        'progress': task['progress'],
        'message': task['message'],
        'created_at': task['created_at']
    }
    
    if task['status'] == 'completed' and task['result']:
        result = task['result']
        response['result'] = {
            'seed': result['seed'],
            'stats': result['stats'],
            'files': {}
        }
        
        if result['white_mesh']:
            rel_path = os.path.relpath(result['white_mesh'], '.')
            response['result']['files']['white_mesh'] = {
                'download_url': f"/download/{rel_path}",
                'filename': os.path.basename(result['white_mesh'])
            }
        
        if result['textured_mesh']:
            rel_path = os.path.relpath(result['textured_mesh'], '.')
            response['result']['files']['textured_mesh'] = {
                'download_url': f"/download/{rel_path}",
                'filename': os.path.basename(result['textured_mesh'])
            }
    
    elif task['status'] == 'failed':
        response['error'] = task['error']
    
    return jsonify(response)

@app.route('/download/<path:filename>')
def download_file(filename):
    """下载生成的文件"""
    try:
        # 安全检查：确保文件路径在允许的目录内
        safe_path = os.path.abspath(filename)
        base_path = os.path.abspath('.')
        
        if not safe_path.startswith(base_path):
            return jsonify({'error': '无效的文件路径'}), 400
        
        if not os.path.exists(safe_path):
            return jsonify({'error': '文件不存在'}), 404
        
        directory = os.path.dirname(safe_path)
        filename = os.path.basename(safe_path)
        
        return send_from_directory(directory, filename, as_attachment=True)
        
    except Exception as e:
        log_message(f"❌ 文件下载失败: {e}")
        return jsonify({'error': f'下载失败: {str(e)}'}), 500

@app.route('/cleanup', methods=['POST'])
def cleanup_old_files():
    """清理旧文件"""
    try:
        cleaned_count = 0
        
        # 清理生成的模型文件（保留最近50个）
        if os.path.exists(OUTPUT_FOLDER):
            dirs = [f for f in Path(OUTPUT_FOLDER).iterdir() if f.is_dir()]
            if len(dirs) > 50:
                dirs_to_remove = sorted(dirs, key=lambda x: x.stat().st_ctime)[:-50]
                for dir_path in dirs_to_remove:
                    shutil.rmtree(dir_path)
                    cleaned_count += 1
        
        # 清理上传的图片文件（保留最近100个）
        if os.path.exists(UPLOAD_FOLDER):
            files = [f for f in Path(UPLOAD_FOLDER).iterdir() if f.is_file()]
            if len(files) > 100:
                files_to_remove = sorted(files, key=lambda x: x.stat().st_ctime)[:-100]
                for file_path in files_to_remove:
                    os.remove(file_path)
                    cleaned_count += 1
        
        # 清理完成的任务记录（保留最近20个）
        completed_tasks = [(k, v) for k, v in generation_tasks.items() 
                          if v['status'] in ['completed', 'failed']]
        if len(completed_tasks) > 20:
            tasks_to_remove = sorted(completed_tasks, 
                                   key=lambda x: x[1]['created_at'])[:-20]
            for task_id, _ in tasks_to_remove:
                del generation_tasks[task_id]
        
        log_message(f"🧹 清理完成，删除了 {cleaned_count} 个文件/文件夹")
        
        return jsonify({
            'success': True,
            'message': f'清理完成，删除了 {cleaned_count} 个项目',
            'cleaned_count': cleaned_count
        })
        
    except Exception as e:
        log_message(f"❌ 清理失败: {e}")
        return jsonify({'error': f'清理失败: {str(e)}'}), 500

@app.errorhandler(413)
def too_large(e):
    return jsonify({'error': '文件太大，最大支持32MB'}), 413

@app.errorhandler(404)
def not_found(e):
    return jsonify({'error': '接口不存在'}), 404

@app.errorhandler(500)
def internal_error(e):
    return jsonify({'error': '服务器内部错误'}), 500

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='Hunyuan3D Flask API Server')
    parser.add_argument('--host', type=str, default='0.0.0.0', help='服务器主机地址')
    parser.add_argument('--port', type=int, default=8001, help='服务器端口')
    parser.add_argument('--model_path', type=str, default='tencent/Hunyuan3D-2.1', 
                       help='3D生成模型路径')
    parser.add_argument('--subfolder', type=str, default='hunyuan3d-dit-v2-1', 
                       help='模型子文件夹')
    parser.add_argument('--texgen_model_path', type=str, default='tencent/Hunyuan3D-2.1',
                       help='纹理生成模型路径')
    parser.add_argument('--low_vram_mode', action='store_true', 
                       help='启用低显存模式')
    parser.add_argument('--enable_t23d', action='store_true', 
                       help='启用文本到3D功能')
    parser.add_argument('--disable_tex', action='store_true', 
                       help='禁用纹理生成')
    parser.add_argument('--mv_mode', action='store_true', 
                       help='启用多视角模式')
    parser.add_argument('--turbo_mode', action='store_true', 
                       help='启用Turbo模式')
    parser.add_argument('--device', type=str, default='auto', 
                       help='计算设备 (auto/cuda/cpu)')
    parser.add_argument('--enable_flashvdm', action='store_true', 
                       help='启用FlashVDM')
    parser.add_argument('--compile', action='store_true', 
                       help='编译模型以提升性能')
    
    return parser.parse_args()


@app.route('/list_models', methods=['GET'])
def list_models():
    """获取服务器上所有生成的模型文件列表"""
    try:
        models_list = []
        
        if os.path.exists(OUTPUT_FOLDER):
            # 遍历所有UUID文件夹
            for folder_name in os.listdir(OUTPUT_FOLDER):
                folder_path = os.path.join(OUTPUT_FOLDER, folder_name)
                if os.path.isdir(folder_path):
                    # 查找textured_mesh.glb文件
                    textured_mesh_path = os.path.join(folder_path, 'textured_mesh.glb')
                    if os.path.exists(textured_mesh_path):
                        file_info = os.stat(textured_mesh_path)
                        
                        # 查找对应的输入图片
                        input_image_url = None
                        input_image_filename = None
                        
                        # 按优先级查找图片文件
                        possible_image_names = [
                            'original_input.png', 'original_input.jpg', 'original_input.jpeg',
                            'input_image.png', 'input_image.jpg', 'input_image.jpeg'
                        ]
                        
                        for img_name in possible_image_names:
                            img_path = os.path.join(folder_path, img_name)
                            if os.path.exists(img_path):
                                input_image_url = f'/download/generated_models/{folder_name}/{img_name}'
                                input_image_filename = img_name
                                break
                        
                        models_list.append({
                            'folder_id': folder_name,
                            'filename': 'textured_mesh.glb',
                            'size': file_info.st_size,
                            'created_time': file_info.st_ctime,
                            'modified_time': file_info.st_mtime,
                            'download_url': f'/download/generated_models/{folder_name}/textured_mesh.glb',
                            'input_image_url': input_image_url,  # 新增：输入图片URL
                            'input_image_filename': input_image_filename  # 新增：输入图片文件名
                        })
        
        # 按修改时间排序（最新的在前）
        models_list.sort(key=lambda x: x['modified_time'], reverse=True)
        
        return jsonify({
            'success': True,
            'models': models_list,
            'total_count': len(models_list)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500



def main():
    """主函数"""
    global server_running, DEFAULT_ARGS
    
    # 解析命令行参数
    args = parse_args()
    
    # 更新默认参数
    DEFAULT_ARGS.model_path = args.model_path
    DEFAULT_ARGS.subfolder = args.subfolder
    DEFAULT_ARGS.texgen_model_path = args.texgen_model_path
    DEFAULT_ARGS.low_vram_mode = args.low_vram_mode
    DEFAULT_ARGS.enable_t23d = args.enable_t23d
    DEFAULT_ARGS.disable_tex = args.disable_tex
    DEFAULT_ARGS.mv_mode = args.mv_mode
    DEFAULT_ARGS.turbo_mode = args.turbo_mode
    DEFAULT_ARGS.enable_flashvdm = args.enable_flashvdm
    DEFAULT_ARGS.compile = args.compile
    
    if args.device == 'auto':
        DEFAULT_ARGS.device = 'cuda' if torch.cuda.is_available() else 'cpu'
    else:
        DEFAULT_ARGS.device = args.device
    
    print("🚀 启动 Hunyuan3D Flask API 服务器")
    print(f"📍 主机: {args.host}:{args.port}")
    print(f"🎯 设备: {DEFAULT_ARGS.device}")
    print(f"🏗️ 模型: {DEFAULT_ARGS.model_path}/{DEFAULT_ARGS.subfolder}")
    print(f"🎨 纹理生成: {'禁用' if DEFAULT_ARGS.disable_tex else '启用'}")
    print(f"📝 文本到3D: {'启用' if DEFAULT_ARGS.enable_t23d else '禁用'}")
    print(f"👁️ 多视角模式: {'启用' if DEFAULT_ARGS.mv_mode else '禁用'}")
    
    # 确保文件夹存在
    ensure_folders()
    
    # 初始化模型
    log_message("🔄 初始化模型...")
    if not init_hunyuan_models():
        log_message("❌ 模型初始化失败，退出")
        return
    
    server_running = True
    log_message("✅ 服务器准备就绪")
    
    try:
        # 启动Flask服务器
        app.run(
            host=args.host,
            port=args.port,
            debug=False,
            threaded=True
        )
    except KeyboardInterrupt:
        log_message("⏹️ 收到中断信号，正在关闭服务器...")
    except Exception as e:
        log_message(f"❌ 服务器运行错误: {e}")
    finally:
        server_running = False
        log_message("👋 服务器已关闭")

if __name__ == '__main__':
    main()
